import { useRouter } from "expo-router";
import { useEffect, useRef } from "react";
import { Animated, Easing, Image, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";

import { colors, radius, spacing } from "@/src/theme";
import { useAuth } from "@/src/auth/AuthContext";

const HERO =
  "https://static.prod-images.emergentagent.com/jobs/e82f8bfe-4972-4972-8cbe-e6bccc505b38/images/6d7e13ec94ca97c2290d182cd507b03fd5860165f884cf22008cc3ed37af23ac.png";

const TIERS = [
  { k: "sub3", l: "Sub-3", c: "#FF3B30" },
  { k: "sub5", l: "Sub-5", c: "#FF6B6B" },
  { k: "ltn", l: "LTN", c: "#FF9F40" },
  { k: "mtn", l: "MTN", c: "#00E5FF" },
  { k: "htn", l: "HTN", c: "#A78BFA" },
  { k: "cl", l: "Chad-Lite", c: "#D4AF37" },
  { k: "chad", l: "Chad", c: "#00FF9D" },
];

const FEATURES = [
  { icon: "scan", title: "11-METRIC SCAN", sub: "AI rates skin, jaw, eyes, hair & 7 more" },
  { icon: "trophy", title: "TIER RANK", sub: "From Sub-3 to Chad — know where you stand" },
  { icon: "star", title: "CELEBRITY MATCH", sub: "See which icons share your bone structure" },
  { icon: "chatbubble-ellipses", title: "AI COACH", sub: "Ask Mog anything, anytime" },
  { icon: "cut", title: "HAIRSTYLE AI", sub: "Render new cuts on YOUR face" },
  { icon: "pricetag", title: "INDIA PICKS", sub: "Skincare + style in ₹, real brands" },
];

export default function Landing() {
  const router = useRouter();
  const { user, loading } = useAuth();
  const pulse = useRef(new Animated.Value(0)).current;
  const fade = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (!loading && user) router.replace("/(tabs)/scan");
  }, [loading, user, router]);

  useEffect(() => {
    Animated.timing(fade, { toValue: 1, duration: 800, useNativeDriver: true }).start();
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, { toValue: 1, duration: 1600, easing: Easing.inOut(Easing.ease), useNativeDriver: true }),
        Animated.timing(pulse, { toValue: 0, duration: 1600, easing: Easing.inOut(Easing.ease), useNativeDriver: true }),
      ]),
    ).start();
  }, [pulse, fade]);

  const pulseScale = pulse.interpolate({ inputRange: [0, 1], outputRange: [1, 1.18] });
  const pulseOpacity = pulse.interpolate({ inputRange: [0, 1], outputRange: [0.6, 0] });

  return (
    <View style={styles.root} testID="landing-screen">
      <SafeAreaView edges={["top"]} style={styles.safeTop}>
        <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
          {/* HERO */}
          <View style={styles.hero}>
            <Image source={{ uri: HERO }} style={styles.heroImg} resizeMode="cover" />
            <LinearGradient
              colors={["rgba(5,5,5,0)", "rgba(5,5,5,0.55)", "#050505"]}
              style={StyleSheet.absoluteFill}
            />

            <View style={styles.brandRow}>
              <View style={styles.brandDot} />
              <Text style={styles.brand}>MOGLABS</Text>
              <View style={styles.pillBeta}>
                <Text style={styles.pillBetaText}>v1 · INDIA</Text>
              </View>
            </View>

            {/* Scan reticle */}
            <View style={styles.reticleWrap}>
              <Animated.View
                style={[
                  styles.pulseRing,
                  { transform: [{ scale: pulseScale }], opacity: pulseOpacity },
                ]}
              />
              <View style={styles.reticle}>
                <View style={[styles.cornerTL, { top: 0, left: 0 }]} />
                <View style={[styles.cornerTR, { top: 0, right: 0 }]} />
                <View style={[styles.cornerBL, { bottom: 0, left: 0 }]} />
                <View style={[styles.cornerBR, { bottom: 0, right: 0 }]} />
                <View style={styles.reticleInner}>
                  <Ionicons name="scan-outline" size={50} color={colors.ice} />
                  <Text style={styles.reticleText}>FACIAL SCAN</Text>
                </View>
              </View>
            </View>

            <Animated.View style={{ opacity: fade }}>
              <Text style={styles.kicker}>AI · 11 METRICS · 7 TIERS</Text>
              <Text style={styles.headline}>
                Rate.{"\n"}Rank.{"\n"}
                <Text style={{ color: colors.ice }}>Ascend.</Text>
              </Text>
              <Text style={styles.sub}>
                The most honest AI mirror you&apos;ll ever own.{"\n"}Built for the Indian face.
              </Text>
            </Animated.View>
          </View>

          {/* TIER LADDER */}
          <View style={styles.section}>
            <Text style={styles.sectionTag}>WHERE WILL YOU LAND?</Text>
            <Text style={styles.sectionTitle}>The Tier Ladder</Text>
            <View style={styles.ladderRow}>
              {TIERS.map((t, i) => (
                <View key={t.k} style={styles.ladderCol}>
                  <View
                    style={[
                      styles.ladderChip,
                      { backgroundColor: `${t.c}20`, borderColor: t.c },
                    ]}
                  >
                    <Text style={[styles.ladderChipText, { color: t.c }]}>{t.l}</Text>
                  </View>
                  <View style={[styles.ladderBar, { height: 10 + i * 8, backgroundColor: t.c, opacity: 0.7 }]} />
                </View>
              ))}
            </View>
            <Text style={styles.ladderCaption}>
              Most start MTN. Targeted protocols can lift you 1-2 tiers in 90 days.
            </Text>
          </View>

          {/* FEATURE GRID */}
          <View style={styles.section}>
            <Text style={styles.sectionTag}>WHAT YOU GET</Text>
            <Text style={styles.sectionTitle}>Six elite tools.{"\n"}One scan.</Text>
            <View style={styles.featGrid}>
              {FEATURES.map((f) => (
                <View key={f.icon} style={styles.featCard}>
                  <View style={styles.featIcon}>
                    <Ionicons name={f.icon as any} size={20} color={colors.ice} />
                  </View>
                  <Text style={styles.featTitle}>{f.title}</Text>
                  <Text style={styles.featSub}>{f.sub}</Text>
                </View>
              ))}
            </View>
          </View>

          {/* SAMPLE CARD */}
          <View style={styles.section}>
            <Text style={styles.sectionTag}>SAMPLE OUTPUT</Text>
            <View style={styles.sampleCard}>
              <LinearGradient
                colors={["rgba(0,229,255,0.08)", "rgba(212,175,55,0.04)"]}
                style={StyleSheet.absoluteFill}
              />
              <View style={styles.sampleTop}>
                <View>
                  <View style={[styles.tierPill, { borderColor: colors.gold }]}>
                    <Text style={[styles.tierPillText, { color: colors.gold }]}>CHAD-LITE</Text>
                  </View>
                  <Text style={styles.sampleScore}>7.9</Text>
                  <Text style={styles.sampleScoreSub}>OVERALL / 10</Text>
                </View>
                <View style={styles.sampleRight}>
                  <Text style={styles.sampleRightLabel}>LOOKS LIKE</Text>
                  <Text style={styles.sampleCeleb}>Vicky Kaushal</Text>
                  <Text style={styles.sampleCelebSub}>Bollywood · 72%</Text>
                </View>
              </View>
              <View style={styles.sampleMetrics}>
                {[
                  { l: "Jaw", v: 8.2, c: colors.ascend },
                  { l: "Skin", v: 7.4, c: colors.ice },
                  { l: "Eyes", v: 8.0, c: colors.ascend },
                  { l: "Hair", v: 6.9, c: colors.ice },
                ].map((m) => (
                  <View key={m.l} style={styles.miniMetric}>
                    <Text style={[styles.miniMetricVal, { color: m.c }]}>{m.v}</Text>
                    <Text style={styles.miniMetricLbl}>{m.l}</Text>
                  </View>
                ))}
              </View>
            </View>
          </View>

          {/* FINAL CTA */}
          <View style={styles.ctaSection}>
            <Text style={styles.ctaKicker}>ENTER THE LAB</Text>
            <Text style={styles.ctaTitle}>Your scan{"\n"}is waiting.</Text>
            <Pressable
              testID="cta-enter-lab"
              style={({ pressed }) => [styles.cta, pressed && { opacity: 0.85 }]}
              onPress={() => router.push("/auth/register")}
            >
              <Text style={styles.ctaText}>BEGIN — FREE</Text>
              <Ionicons name="arrow-forward" size={18} color="#000" style={{ marginLeft: 6 }} />
            </Pressable>
            <Pressable
              testID="cta-login"
              onPress={() => router.push("/auth/login")}
              style={styles.secondary}
            >
              <Text style={styles.secondaryText}>I already have an account</Text>
            </Pressable>
            <Text style={styles.footnote}>NO ADS · NO TRACKING · 100% FREE</Text>
          </View>
        </ScrollView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  safeTop: { flex: 1 },
  scroll: { paddingBottom: spacing.xxxl },

  hero: { paddingHorizontal: spacing.xl, paddingTop: spacing.lg, paddingBottom: spacing.xxxl, position: "relative", overflow: "hidden", minHeight: 720 },
  heroImg: { ...StyleSheet.absoluteFillObject, opacity: 0.45 },
  brandRow: { flexDirection: "row", alignItems: "center", gap: spacing.sm, marginBottom: spacing.xxxl },
  brandDot: { width: 10, height: 10, borderRadius: 5, backgroundColor: colors.ice, shadowColor: colors.ice, shadowOpacity: 1, shadowRadius: 12 },
  brand: { color: "#fff", letterSpacing: 6, fontSize: 14, fontWeight: "900", flex: 1 },
  pillBeta: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 999, borderWidth: 1, borderColor: colors.borderActive, backgroundColor: "rgba(0,229,255,0.08)" },
  pillBetaText: { color: colors.ice, fontSize: 9, letterSpacing: 1.5, fontWeight: "800" },

  reticleWrap: { alignItems: "center", justifyContent: "center", marginVertical: spacing.xl, height: 220 },
  pulseRing: {
    position: "absolute",
    width: 200,
    height: 200,
    borderRadius: 100,
    borderWidth: 2,
    borderColor: colors.ice,
  },
  reticle: { width: 180, height: 180, alignItems: "center", justifyContent: "center", position: "relative" },
  cornerTL: { position: "absolute", width: 28, height: 28, borderTopWidth: 3, borderLeftWidth: 3, borderColor: colors.ice },
  cornerTR: { position: "absolute", width: 28, height: 28, borderTopWidth: 3, borderRightWidth: 3, borderColor: colors.ice },
  cornerBL: { position: "absolute", width: 28, height: 28, borderBottomWidth: 3, borderLeftWidth: 3, borderColor: colors.ice },
  cornerBR: { position: "absolute", width: 28, height: 28, borderBottomWidth: 3, borderRightWidth: 3, borderColor: colors.ice },
  reticleInner: { alignItems: "center", gap: 6 },
  reticleText: { color: colors.ice, fontSize: 10, fontWeight: "800", letterSpacing: 3 },

  kicker: { color: colors.ice, letterSpacing: 4, fontSize: 11, fontWeight: "800", marginBottom: spacing.md, marginTop: spacing.lg },
  headline: { color: "#fff", fontSize: 62, fontWeight: "900", letterSpacing: -3, lineHeight: 64, marginBottom: spacing.md },
  sub: { color: colors.textSecondary, fontSize: 15, lineHeight: 22, marginBottom: spacing.xl },

  section: { paddingHorizontal: spacing.xl, paddingTop: spacing.xxxl },
  sectionTag: { color: colors.ice, letterSpacing: 4, fontSize: 10, fontWeight: "800", marginBottom: spacing.sm },
  sectionTitle: { color: "#fff", fontSize: 32, fontWeight: "900", letterSpacing: -1.2, marginBottom: spacing.xl, lineHeight: 36 },

  ladderRow: { flexDirection: "row", alignItems: "flex-end", gap: 4, marginBottom: spacing.md, height: 110 },
  ladderCol: { flex: 1, alignItems: "center", gap: 6 },
  ladderChip: { paddingHorizontal: 6, paddingVertical: 4, borderRadius: 6, borderWidth: 1, minWidth: 38, alignItems: "center" },
  ladderChipText: { fontSize: 9, fontWeight: "900", letterSpacing: 0.5 },
  ladderBar: { width: "70%", borderRadius: 2 },
  ladderCaption: { color: colors.textSecondary, fontSize: 12, lineHeight: 18, fontStyle: "italic" },

  featGrid: { flexDirection: "row", flexWrap: "wrap", gap: spacing.md },
  featCard: { width: "47%", backgroundColor: colors.surface1, borderRadius: radius.lg, padding: spacing.md, borderWidth: 1, borderColor: colors.borderSubtle, gap: spacing.sm, minHeight: 130 },
  featIcon: { width: 40, height: 40, borderRadius: 20, backgroundColor: "rgba(0,229,255,0.12)", alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: colors.borderActive },
  featTitle: { color: "#fff", fontWeight: "900", fontSize: 13, letterSpacing: 0.5 },
  featSub: { color: colors.textSecondary, fontSize: 11, lineHeight: 15 },

  sampleCard: { backgroundColor: colors.surface1, borderRadius: radius.xl, padding: spacing.xl, borderWidth: 1, borderColor: colors.borderActive, overflow: "hidden" },
  sampleTop: { flexDirection: "row", justifyContent: "space-between", marginBottom: spacing.lg },
  tierPill: { alignSelf: "flex-start", paddingHorizontal: 10, paddingVertical: 4, borderRadius: 999, borderWidth: 1, marginBottom: spacing.sm },
  tierPillText: { fontSize: 10, fontWeight: "900", letterSpacing: 2 },
  sampleScore: { color: colors.gold, fontSize: 56, fontWeight: "900", letterSpacing: -3, lineHeight: 58 },
  sampleScoreSub: { color: colors.textTertiary, fontSize: 9, letterSpacing: 2, fontWeight: "800" },
  sampleRight: { alignItems: "flex-end" },
  sampleRightLabel: { color: colors.textTertiary, fontSize: 9, letterSpacing: 2, fontWeight: "800" },
  sampleCeleb: { color: "#fff", fontSize: 18, fontWeight: "900", marginTop: 4 },
  sampleCelebSub: { color: colors.gold, fontSize: 11, fontWeight: "700", marginTop: 2 },
  sampleMetrics: { flexDirection: "row", justifyContent: "space-between", paddingTop: spacing.md, borderTopWidth: 1, borderTopColor: colors.borderSubtle },
  miniMetric: { alignItems: "center" },
  miniMetricVal: { fontSize: 22, fontWeight: "900", letterSpacing: -1 },
  miniMetricLbl: { color: colors.textTertiary, fontSize: 10, letterSpacing: 1.5, fontWeight: "700", marginTop: 2 },

  ctaSection: { paddingHorizontal: spacing.xl, paddingTop: spacing.xxxl, alignItems: "center" },
  ctaKicker: { color: colors.ice, letterSpacing: 4, fontSize: 11, fontWeight: "900", marginBottom: spacing.sm },
  ctaTitle: { color: "#fff", fontSize: 42, fontWeight: "900", letterSpacing: -1.5, textAlign: "center", marginBottom: spacing.xl, lineHeight: 46 },
  cta: {
    flexDirection: "row",
    backgroundColor: colors.ice,
    paddingVertical: 18,
    paddingHorizontal: spacing.xxxl,
    borderRadius: radius.pill,
    alignItems: "center",
    shadowColor: colors.ice,
    shadowOpacity: 0.6,
    shadowRadius: 24,
  },
  ctaText: { color: "#000", fontWeight: "900", letterSpacing: 3, fontSize: 14 },
  secondary: { marginTop: spacing.md, paddingVertical: 14 },
  secondaryText: { color: colors.textSecondary, fontSize: 14, fontWeight: "600" },
  footnote: { color: colors.textTertiary, fontSize: 10, marginTop: spacing.xl, letterSpacing: 2, fontWeight: "800" },
});
