import { useRouter } from "expo-router";
import { useState } from "react";
import {
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";

import { colors, radius, spacing } from "@/src/theme";
import { useAuth } from "@/src/auth/AuthContext";

export default function Login() {
  const router = useRouter();
  const { login } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const submit = async () => {
    setError(null);
    setLoading(true);
    try {
      await login(email.trim(), password);
      router.replace("/(tabs)/scan");
    } catch (e: any) {
      setError(e.message || "Login failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.root} edges={["top", "bottom"]}>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        <ScrollView
          contentContainerStyle={styles.scroll}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          <Pressable onPress={() => router.back()} style={styles.back} testID="back-button">
            <Ionicons name="chevron-back" size={26} color="#fff" />
          </Pressable>

          <Text style={styles.kicker}>WELCOME BACK</Text>
          <Text style={styles.title}>Resume your{"\n"}ascent.</Text>

          <View style={styles.field}>
            <Text style={styles.label}>EMAIL</Text>
            <TextInput
              testID="login-email-input"
              style={styles.input}
              placeholder="you@moglabs.com"
              placeholderTextColor={colors.textTertiary}
              value={email}
              onChangeText={setEmail}
              autoCapitalize="none"
              keyboardType="email-address"
              autoCorrect={false}
            />
          </View>

          <View style={styles.field}>
            <Text style={styles.label}>PASSWORD</Text>
            <TextInput
              testID="login-password-input"
              style={styles.input}
              placeholder="••••••••"
              placeholderTextColor={colors.textTertiary}
              value={password}
              onChangeText={setPassword}
              secureTextEntry
            />
          </View>

          {error ? (
            <Text style={styles.error} testID="login-error">
              {error}
            </Text>
          ) : null}

          <Pressable
            testID="login-submit"
            onPress={submit}
            disabled={loading}
            style={({ pressed }) => [styles.cta, pressed && { opacity: 0.85 }, loading && { opacity: 0.6 }]}
          >
            {loading ? (
              <ActivityIndicator color="#000" />
            ) : (
              <Text style={styles.ctaText}>LOG IN</Text>
            )}
          </Pressable>

          <Pressable onPress={() => router.replace("/auth/register")} style={{ marginTop: spacing.xl }}>
            <Text style={styles.switchText}>
              New here? <Text style={{ color: colors.ice }}>Create an account</Text>
            </Text>
          </Pressable>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  scroll: { padding: spacing.xl, flexGrow: 1 },
  back: { width: 40, height: 40, alignItems: "center", justifyContent: "center", marginLeft: -spacing.sm },
  kicker: { color: colors.ice, letterSpacing: 4, fontSize: 11, fontWeight: "800", marginTop: spacing.lg },
  title: { color: "#fff", fontSize: 40, fontWeight: "900", letterSpacing: -1.5, marginTop: spacing.sm, marginBottom: spacing.xxl, lineHeight: 44 },
  field: { marginBottom: spacing.lg },
  label: { color: colors.textTertiary, fontSize: 10, letterSpacing: 2, fontWeight: "800", marginBottom: spacing.sm },
  input: {
    backgroundColor: colors.surface1,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.borderSubtle,
    paddingHorizontal: spacing.lg,
    paddingVertical: 14,
    color: "#fff",
    fontSize: 16,
    fontWeight: "500",
  },
  error: { color: colors.descend, marginBottom: spacing.md, fontSize: 13 },
  cta: {
    backgroundColor: colors.ice,
    paddingVertical: 18,
    borderRadius: radius.pill,
    alignItems: "center",
    marginTop: spacing.md,
  },
  ctaText: { color: "#000", fontWeight: "900", letterSpacing: 3, fontSize: 14 },
  switchText: { color: colors.textSecondary, fontSize: 14, textAlign: "center" },
});
