import { useRouter } from "expo-router";
import { useState } from "react";
import {
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";

import { colors, radius, spacing } from "@/src/theme";
import { useAuth } from "@/src/auth/AuthContext";

export default function Register() {
  const router = useRouter();
  const { register } = useAuth();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const submit = async () => {
    setError(null);
    if (password.length < 6) {
      setError("Password must be at least 6 characters");
      return;
    }
    setLoading(true);
    try {
      await register(email.trim(), password, name.trim() || undefined);
      router.replace("/(tabs)/scan");
    } catch (e: any) {
      setError(e.message || "Registration failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.root} edges={["top", "bottom"]}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
          <Pressable onPress={() => router.back()} style={styles.back} testID="back-button">
            <Ionicons name="chevron-back" size={26} color="#fff" />
          </Pressable>

          <Text style={styles.kicker}>NEW SUBJECT</Text>
          <Text style={styles.title}>Begin your{"\n"}analysis.</Text>

          <View style={styles.field}>
            <Text style={styles.label}>NAME (OPTIONAL)</Text>
            <TextInput
              testID="register-name-input"
              style={styles.input}
              placeholder="Alex"
              placeholderTextColor={colors.textTertiary}
              value={name}
              onChangeText={setName}
              autoCapitalize="words"
            />
          </View>

          <View style={styles.field}>
            <Text style={styles.label}>EMAIL</Text>
            <TextInput
              testID="register-email-input"
              style={styles.input}
              placeholder="you@moglabs.com"
              placeholderTextColor={colors.textTertiary}
              value={email}
              onChangeText={setEmail}
              autoCapitalize="none"
              keyboardType="email-address"
              autoCorrect={false}
            />
          </View>

          <View style={styles.field}>
            <Text style={styles.label}>PASSWORD</Text>
            <TextInput
              testID="register-password-input"
              style={styles.input}
              placeholder="Min 6 characters"
              placeholderTextColor={colors.textTertiary}
              value={password}
              onChangeText={setPassword}
              secureTextEntry
            />
          </View>

          {error ? (
            <Text style={styles.error} testID="register-error">
              {error}
            </Text>
          ) : null}

          <Pressable
            testID="register-submit"
            onPress={submit}
            disabled={loading}
            style={({ pressed }) => [styles.cta, pressed && { opacity: 0.85 }, loading && { opacity: 0.6 }]}
          >
            {loading ? <ActivityIndicator color="#000" /> : <Text style={styles.ctaText}>CREATE ACCOUNT</Text>}
          </Pressable>

          <Pressable onPress={() => router.replace("/auth/login")} style={{ marginTop: spacing.xl }}>
            <Text style={styles.switchText}>
              Already a subject? <Text style={{ color: colors.ice }}>Log in</Text>
            </Text>
          </Pressable>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  scroll: { padding: spacing.xl, flexGrow: 1 },
  back: { width: 40, height: 40, alignItems: "center", justifyContent: "center", marginLeft: -spacing.sm },
  kicker: { color: colors.ice, letterSpacing: 4, fontSize: 11, fontWeight: "800", marginTop: spacing.lg },
  title: { color: "#fff", fontSize: 40, fontWeight: "900", letterSpacing: -1.5, marginTop: spacing.sm, marginBottom: spacing.xxl, lineHeight: 44 },
  field: { marginBottom: spacing.lg },
  label: { color: colors.textTertiary, fontSize: 10, letterSpacing: 2, fontWeight: "800", marginBottom: spacing.sm },
  input: {
    backgroundColor: colors.surface1,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.borderSubtle,
    paddingHorizontal: spacing.lg,
    paddingVertical: 14,
    color: "#fff",
    fontSize: 16,
    fontWeight: "500",
  },
  error: { color: colors.descend, marginBottom: spacing.md, fontSize: 13 },
  cta: {
    backgroundColor: colors.ice,
    paddingVertical: 18,
    borderRadius: radius.pill,
    alignItems: "center",
    marginTop: spacing.md,
  },
  ctaText: { color: "#000", fontWeight: "900", letterSpacing: 3, fontSize: 14 },
  switchText: { color: colors.textSecondary, fontSize: 14, textAlign: "center" },
});
