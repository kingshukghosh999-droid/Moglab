import { useRouter } from "expo-router";
import { useState } from "react";
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import * as WebBrowser from "expo-web-browser";

import { colors, radius, spacing } from "@/src/theme";
import { apiFetch, useAuth } from "@/src/auth/AuthContext";

const PERKS = [
  { icon: "sparkles", text: "AI-rendered hairstyle previews on your face" },
  { icon: "flask", text: "Personalized skincare & haircare protocols" },
  { icon: "trending-up", text: "Full progress tracking across every scan" },
  { icon: "shield-checkmark", text: "Zero ads. Forever." },
  { icon: "infinite", text: "Unlimited scans + priority analysis" },
];

export default function Paywall() {
  const router = useRouter();
  const { token, refreshUser } = useAuth();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [pollState, setPollState] = useState<"idle" | "checking">("idle");

  const ascend = async () => {
    if (!token) return;
    setLoading(true);
    setError(null);
    try {
      const res = await apiFetch<{ checkout_url: string; session_id: string }>(
        "/payments/create-checkout-session",
        { method: "POST" },
        token,
      );
      setSessionId(res.session_id);
      await WebBrowser.openBrowserAsync(res.checkout_url);
    } catch (e: any) {
      setError(e.message || "Unable to start checkout");
    } finally {
      setLoading(false);
    }
  };

  const verify = async () => {
    if (!token || !sessionId) return;
    setPollState("checking");
    setError(null);
    try {
      const res = await apiFetch<{ paid: boolean }>(
        `/payments/status/${sessionId}`,
        { method: "GET" },
        token,
      );
      if (res.paid) {
        await refreshUser();
        router.replace("/(tabs)/suggestions");
      } else {
        setError("Payment not completed yet. Try again after finishing checkout.");
      }
    } catch (e: any) {
      setError(e.message || "Verification failed");
    } finally {
      setPollState("idle");
    }
  };

  return (
    <SafeAreaView style={styles.root} edges={["top", "bottom"]}>
      <ScrollView contentContainerStyle={styles.scroll} testID="paywall-screen" showsVerticalScrollIndicator={false}>
        <View style={styles.headerRow}>
          <Pressable onPress={() => router.back()} style={styles.backBtn} testID="paywall-back">
            <Ionicons name="close" size={26} color="#fff" />
          </Pressable>
        </View>

        <View style={styles.diamond}>
          <LinearGradient colors={["#D4AF37", "#8B7228"]} style={StyleSheet.absoluteFill} />
          <Ionicons name="diamond" size={48} color="#000" />
        </View>

        <Text style={styles.kicker}>MOGLABS ASCEND</Text>
        <Text style={styles.title}>
          Unlock your{"\n"}
          <Text style={{ color: colors.gold }}>full potential.</Text>
        </Text>

        <View style={styles.priceRow}>
          <Text style={styles.dollar}>$</Text>
          <Text style={styles.price}>1</Text>
          <Text style={styles.per}>/month</Text>
        </View>
        <Text style={styles.subtitle}>One coffee. One month of elite access.</Text>

        <View style={styles.perks}>
          {PERKS.map((p) => (
            <View key={p.icon} style={styles.perk}>
              <View style={styles.perkIcon}>
                <Ionicons name={p.icon as any} size={18} color={colors.gold} />
              </View>
              <Text style={styles.perkText}>{p.text}</Text>
            </View>
          ))}
        </View>

        {error ? (
          <Text style={styles.error} testID="paywall-error">
            {error}
          </Text>
        ) : null}

        <Pressable
          testID="paywall-ascend"
          disabled={loading}
          onPress={ascend}
          style={({ pressed }) => [styles.cta, (loading || pressed) && { opacity: 0.85 }]}
        >
          {loading ? <ActivityIndicator color="#000" /> : <Text style={styles.ctaText}>ASCEND NOW — $1</Text>}
        </Pressable>

        {sessionId ? (
          <Pressable
            testID="paywall-verify"
            onPress={verify}
            style={[styles.verify, pollState === "checking" && { opacity: 0.7 }]}
            disabled={pollState === "checking"}
          >
            <Text style={styles.verifyText}>
              {pollState === "checking" ? "VERIFYING…" : "I'VE COMPLETED PAYMENT"}
            </Text>
          </Pressable>
        ) : null}

        <Text style={styles.legal}>Cancel anytime. No ads, no tracking, no fluff.</Text>
        <View style={{ height: 40 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  scroll: { padding: spacing.xl, alignItems: "center" },
  headerRow: { width: "100%", alignItems: "flex-end" },
  backBtn: { width: 40, height: 40, alignItems: "center", justifyContent: "center" },
  diamond: {
    width: 88,
    height: 88,
    borderRadius: 24,
    overflow: "hidden",
    alignItems: "center",
    justifyContent: "center",
    marginTop: spacing.md,
    marginBottom: spacing.xl,
    shadowColor: colors.gold,
    shadowOpacity: 0.5,
    shadowRadius: 20,
  },
  kicker: { color: colors.gold, letterSpacing: 4, fontSize: 11, fontWeight: "900", marginBottom: spacing.sm },
  title: { color: "#fff", fontSize: 38, fontWeight: "900", letterSpacing: -1.5, textAlign: "center", lineHeight: 42, marginBottom: spacing.xl },
  priceRow: { flexDirection: "row", alignItems: "flex-end", marginBottom: spacing.xs },
  dollar: { color: colors.gold, fontSize: 28, fontWeight: "900", marginBottom: 14 },
  price: { color: "#fff", fontSize: 96, fontWeight: "900", letterSpacing: -5, lineHeight: 96 },
  per: { color: colors.textSecondary, fontSize: 16, marginBottom: 18, marginLeft: 4 },
  subtitle: { color: colors.textSecondary, fontSize: 14, marginBottom: spacing.xxl },
  perks: { width: "100%", gap: spacing.md, marginBottom: spacing.xxl },
  perk: { flexDirection: "row", gap: spacing.md, alignItems: "center", paddingVertical: spacing.sm },
  perkIcon: { width: 36, height: 36, borderRadius: 18, backgroundColor: "rgba(212,175,55,0.12)", alignItems: "center", justifyContent: "center" },
  perkText: { color: "#fff", flex: 1, fontSize: 15, fontWeight: "600" },
  error: { color: colors.descend, marginBottom: spacing.md, textAlign: "center" },
  cta: {
    backgroundColor: colors.gold,
    paddingVertical: 20,
    paddingHorizontal: spacing.xxxl,
    borderRadius: radius.pill,
    alignItems: "center",
    width: "100%",
    shadowColor: colors.gold,
    shadowOpacity: 0.5,
    shadowRadius: 16,
  },
  ctaText: { color: "#000", fontWeight: "900", letterSpacing: 3, fontSize: 15 },
  verify: { marginTop: spacing.md, paddingVertical: 14, alignItems: "center", width: "100%" },
  verifyText: { color: colors.ice, fontWeight: "900", letterSpacing: 2, fontSize: 12 },
  legal: { color: colors.textTertiary, fontSize: 11, textAlign: "center", marginTop: spacing.lg, letterSpacing: 0.5 },
});
