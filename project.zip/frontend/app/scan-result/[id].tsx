import { useLocalSearchParams, useRouter } from "expo-router";
import { useEffect, useState } from "react";
import {
  ActivityIndicator,
  Image,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";

import { colors, radius, spacing } from "@/src/theme";
import { apiFetch, useAuth } from "@/src/auth/AuthContext";

type Metric = { key: string; label: string; score: number; note: string };
type Product = { name: string; brand: string; price_inr: string; why: string };
type Celebrity = { name: string; industry: string; similarity: number; shared_features: string };
type StyleRec = {
  outfit_colors?: string[];
  colors_to_avoid?: string[];
  jewelry?: string;
  accessories?: string[];
};
type ScanFull = {
  id: string;
  overall_score: number;
  symmetry_score: number;
  tier?: string;
  tier_label?: string;
  tier_explanation?: string;
  face_shape: string;
  hairline_type: string;
  skin_undertone?: string;
  metrics: Metric[];
  skin_products?: Product[];
  hair_products?: Product[];
  looksmax_methods?: string[];
  style_recommendations?: StyleRec;
  celebrity_lookalikes?: Celebrity[];
  summary: string;
  image_b64: string;
  created_at: string;
};

const TIER_STYLES: Record<string, { color: string; bg: string; label: string }> = {
  sub3: { color: "#FF3B30", bg: "rgba(255,59,48,0.15)", label: "SUB-3" },
  sub5: { color: "#FF6B6B", bg: "rgba(255,107,107,0.15)", label: "SUB-5" },
  ltn: { color: "#FF9F40", bg: "rgba(255,159,64,0.15)", label: "LTN" },
  mtn: { color: "#00E5FF", bg: "rgba(0,229,255,0.15)", label: "MTN" },
  htn: { color: "#A78BFA", bg: "rgba(167,139,250,0.18)", label: "HTN" },
  "chad-lite": { color: "#D4AF37", bg: "rgba(212,175,55,0.18)", label: "CHAD-LITE" },
  chad: { color: "#00FF9D", bg: "rgba(0,255,157,0.18)", label: "CHAD" },
};

export default function ScanResult() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const { token } = useAuth();
  const [scan, setScan] = useState<ScanFull | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      if (!token || !id) return;
      try {
        const data = await apiFetch<ScanFull>(`/scans/${id}`, { method: "GET" }, token);
        setScan(data);
      } finally {
        setLoading(false);
      }
    })();
  }, [token, id]);

  if (loading) {
    return (
      <View style={[styles.root, { alignItems: "center", justifyContent: "center" }]}>
        <ActivityIndicator color={colors.ice} />
      </View>
    );
  }

  if (!scan) {
    return (
      <View style={[styles.root, { alignItems: "center", justifyContent: "center", padding: spacing.xl }]}>
        <Text style={{ color: "#fff" }}>Scan not found</Text>
        <Pressable onPress={() => router.back()} style={{ marginTop: spacing.lg }}>
          <Text style={{ color: colors.ice }}>Go back</Text>
        </Pressable>
      </View>
    );
  }

  const scoreColor =
    scan.overall_score >= 7 ? colors.ascend : scan.overall_score >= 5 ? colors.ice : colors.descend;
  const tierKey = (scan.tier || "mtn").toLowerCase();
  const tierStyle = TIER_STYLES[tierKey] || TIER_STYLES.mtn;
  const style = scan.style_recommendations || {};

  return (
    <SafeAreaView style={styles.root} edges={["top"]}>
      <ScrollView contentContainerStyle={styles.scroll} testID="scan-result-screen" showsVerticalScrollIndicator={false}>
        <View style={styles.headerRow}>
          <Pressable onPress={() => router.back()} testID="result-back" style={styles.backBtn}>
            <Ionicons name="chevron-back" size={24} color="#fff" />
          </Pressable>
          <Text style={styles.kicker}>SCAN RESULT</Text>
          <View style={{ width: 40 }} />
        </View>

        <View style={styles.heroRow}>
          <Image
            source={{ uri: `data:image/jpeg;base64,${scan.image_b64}` }}
            style={styles.face}
            resizeMode="cover"
          />
          <View style={styles.scoreBox}>
            <View style={[styles.tierBadge, { backgroundColor: tierStyle.bg, borderColor: tierStyle.color }]}>
              <Text style={[styles.tierBadgeText, { color: tierStyle.color }]}>
                {scan.tier_label || tierStyle.label}
              </Text>
            </View>
            <Text style={styles.scoreLabel}>OVERALL</Text>
            <View style={{ flexDirection: "row", alignItems: "flex-end" }}>
              <Text style={[styles.scoreValue, { color: scoreColor }]}>
                {scan.overall_score.toFixed(1)}
              </Text>
              <Text style={styles.scoreOutOf}>/10</Text>
            </View>
            <View style={styles.symmetry}>
              <Text style={styles.symmetryLabel}>SYMMETRY</Text>
              <Text style={styles.symmetryValue}>{scan.symmetry_score.toFixed(1)}</Text>
            </View>
          </View>
        </View>

        {scan.tier_explanation ? (
          <View style={[styles.tierCard, { borderColor: tierStyle.color }]}>
            <Text style={[styles.tierCardLabel, { color: tierStyle.color }]}>
              WHY YOU&apos;RE {scan.tier_label || tierStyle.label}
            </Text>
            <Text style={styles.tierCardText}>{scan.tier_explanation}</Text>
          </View>
        ) : null}

        <View style={styles.tagRow}>
          <View style={styles.tag}>
            <Text style={styles.tagLabel}>FACE</Text>
            <Text style={styles.tagValue}>{scan.face_shape}</Text>
          </View>
          <View style={styles.tag}>
            <Text style={styles.tagLabel}>HAIRLINE</Text>
            <Text style={styles.tagValue}>{scan.hairline_type}</Text>
          </View>
          <View style={styles.tag}>
            <Text style={styles.tagLabel}>SKIN</Text>
            <Text style={styles.tagValue}>{scan.skin_undertone || "neutral"}</Text>
          </View>
        </View>

        <View style={styles.summaryCard}>
          <Text style={styles.summaryLabel}>VERDICT</Text>
          <Text style={styles.summaryText}>{scan.summary}</Text>
        </View>

        {scan.celebrity_lookalikes && scan.celebrity_lookalikes.length > 0 ? (
          <>
            <Text style={styles.section}>YOU LOOK LIKE</Text>
            {scan.celebrity_lookalikes.map((c, i) => (
              <View key={i} style={styles.celebCard} testID={`celeb-${i}`}>
                <View style={styles.celebRank}>
                  <Text style={styles.celebRankText}>#{i + 1}</Text>
                </View>
                <View style={{ flex: 1 }}>
                  <View style={styles.celebHeader}>
                    <Text style={styles.celebName}>{c.name}</Text>
                    <Text style={styles.celebIndustry}>{c.industry}</Text>
                  </View>
                  <Text style={styles.celebShared}>{c.shared_features}</Text>
                  <View style={styles.matchBarBg}>
                    <LinearGradient
                      colors={[colors.gold, "rgba(212,175,55,0.2)"]}
                      start={{ x: 0, y: 0 }}
                      end={{ x: 1, y: 0 }}
                      style={[styles.matchBarFill, { width: `${Math.min(100, Math.max(0, c.similarity))}%` }]}
                    />
                  </View>
                </View>
                <Text style={styles.matchPct}>{Math.round(c.similarity)}%</Text>
              </View>
            ))}
          </>
        ) : null}

        {scan.looksmax_methods && scan.looksmax_methods.length > 0 ? (
          <>
            <Text style={styles.section}>YOUR LOOKSMAX PROTOCOL</Text>
            <View style={styles.methodsList}>
              {scan.looksmax_methods.map((m, i) => (
                <View key={i} style={styles.methodRow}>
                  <View style={styles.methodNum}>
                    <Text style={styles.methodNumText}>{i + 1}</Text>
                  </View>
                  <Text style={styles.methodText}>{m}</Text>
                </View>
              ))}
            </View>
          </>
        ) : null}

        <Text style={styles.section}>METRIC BREAKDOWN</Text>
        {scan.metrics.map((m) => {
          const pct = Math.max(0, Math.min(10, m.score)) / 10;
          const c = m.score >= 7 ? colors.ascend : m.score >= 5 ? colors.ice : colors.descend;
          return (
            <View key={m.key} style={styles.metricCard} testID={`metric-${m.key}`}>
              <View style={styles.metricHeader}>
                <Text style={styles.metricLabel}>{m.label}</Text>
                <Text style={[styles.metricScore, { color: c }]}>{m.score.toFixed(1)}</Text>
              </View>
              <View style={styles.metricBarBg}>
                <LinearGradient
                  colors={[c, "rgba(255,255,255,0.05)"]}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 0 }}
                  style={[styles.metricBarFill, { width: `${pct * 100}%` }]}
                />
              </View>
              <Text style={styles.metricNote}>{m.note}</Text>
            </View>
          );
        })}

        {style.outfit_colors && style.outfit_colors.length > 0 ? (
          <>
            <Text style={styles.section}>YOUR COLOR PALETTE</Text>
            <View style={styles.styleCard}>
              <Text style={styles.styleSubLabel}>WEAR THESE</Text>
              <View style={styles.colorRow}>
                {style.outfit_colors.map((c) => (
                  <View key={c} style={styles.colorChip}>
                    <Text style={styles.colorChipText}>{c}</Text>
                  </View>
                ))}
              </View>
              {style.colors_to_avoid && style.colors_to_avoid.length > 0 ? (
                <>
                  <Text style={[styles.styleSubLabel, { marginTop: spacing.md }]}>AVOID</Text>
                  <View style={styles.colorRow}>
                    {style.colors_to_avoid.map((c) => (
                      <View key={c} style={[styles.colorChip, styles.colorChipAvoid]}>
                        <Text style={[styles.colorChipText, { color: colors.descend }]}>{c}</Text>
                      </View>
                    ))}
                  </View>
                </>
              ) : null}
              {style.jewelry ? (
                <View style={styles.jewelryRow}>
                  <Ionicons name="diamond" size={16} color={colors.gold} />
                  <Text style={styles.jewelryText}>
                    <Text style={{ color: colors.gold, fontWeight: "900" }}>Jewelry: </Text>
                    {style.jewelry}
                  </Text>
                </View>
              ) : null}
              {style.accessories && style.accessories.length > 0 ? (
                <>
                  <Text style={[styles.styleSubLabel, { marginTop: spacing.md }]}>ACCESSORIES</Text>
                  {style.accessories.map((a, i) => (
                    <View key={i} style={styles.accBullet}>
                      <View style={styles.accDot} />
                      <Text style={styles.accText}>{a}</Text>
                    </View>
                  ))}
                </>
              ) : null}
            </View>
          </>
        ) : null}

        <Pressable
          testID="result-see-suggestions"
          style={styles.cta}
          onPress={() => router.push("/(tabs)/suggestions")}
        >
          <Text style={styles.ctaText}>SEE PRODUCT PICKS</Text>
        </Pressable>

        <View style={{ height: 80 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  scroll: { padding: spacing.xl },
  headerRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: spacing.xl },
  backBtn: { width: 40, height: 40, alignItems: "center", justifyContent: "center" },
  kicker: { color: colors.ice, letterSpacing: 3, fontSize: 11, fontWeight: "800" },
  heroRow: { flexDirection: "row", gap: spacing.md, marginBottom: spacing.lg },
  face: { width: 130, height: 200, borderRadius: radius.lg, borderWidth: 1, borderColor: colors.borderActive },
  scoreBox: {
    flex: 1,
    backgroundColor: colors.surface1,
    borderRadius: radius.lg,
    padding: spacing.md,
    borderWidth: 1,
    borderColor: colors.borderActive,
    justifyContent: "space-between",
  },
  tierBadge: {
    alignSelf: "flex-start",
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: radius.pill,
    borderWidth: 1,
    marginBottom: spacing.sm,
  },
  tierBadgeText: { fontSize: 10, fontWeight: "900", letterSpacing: 2 },
  scoreLabel: { color: colors.textTertiary, fontSize: 10, letterSpacing: 2, fontWeight: "800" },
  scoreValue: { fontSize: 60, fontWeight: "900", letterSpacing: -3, lineHeight: 62 },
  scoreOutOf: { color: colors.textSecondary, fontSize: 14, marginBottom: 12, marginLeft: 4 },
  symmetry: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: spacing.sm },
  symmetryLabel: { color: colors.textTertiary, fontSize: 9, letterSpacing: 1.5, fontWeight: "800" },
  symmetryValue: { color: "#fff", fontSize: 18, fontWeight: "900" },
  tierCard: {
    backgroundColor: colors.surface1,
    borderRadius: radius.lg,
    padding: spacing.md,
    borderWidth: 1,
    marginBottom: spacing.lg,
  },
  tierCardLabel: { fontSize: 10, letterSpacing: 2, fontWeight: "900", marginBottom: spacing.sm },
  tierCardText: { color: "#fff", fontSize: 14, lineHeight: 20 },
  tagRow: { flexDirection: "row", gap: spacing.sm, marginBottom: spacing.lg },
  tag: { flex: 1, backgroundColor: colors.surface1, padding: spacing.md, borderRadius: radius.md, borderWidth: 1, borderColor: colors.borderSubtle },
  tagLabel: { color: colors.textTertiary, fontSize: 9, letterSpacing: 2, fontWeight: "800" },
  tagValue: { color: "#fff", fontSize: 14, fontWeight: "800", marginTop: 2, textTransform: "capitalize" },
  summaryCard: { backgroundColor: colors.surface1, borderRadius: radius.lg, padding: spacing.lg, borderWidth: 1, borderColor: colors.borderActive, marginBottom: spacing.xxl },
  summaryLabel: { color: colors.ice, fontSize: 10, letterSpacing: 2, fontWeight: "800", marginBottom: spacing.sm },
  summaryText: { color: "#fff", fontSize: 15, lineHeight: 22 },
  section: { color: colors.textTertiary, fontSize: 10, letterSpacing: 3, fontWeight: "800", marginBottom: spacing.md, marginTop: spacing.lg },
  methodsList: { marginBottom: spacing.lg },
  methodRow: { flexDirection: "row", gap: spacing.md, alignItems: "flex-start", marginBottom: spacing.md, backgroundColor: colors.surface1, borderRadius: radius.md, padding: spacing.md, borderWidth: 1, borderColor: colors.borderSubtle },
  methodNum: { width: 28, height: 28, borderRadius: 14, backgroundColor: colors.ice, alignItems: "center", justifyContent: "center" },
  methodNumText: { color: "#000", fontWeight: "900", fontSize: 13 },
  methodText: { color: "#fff", flex: 1, fontSize: 14, lineHeight: 20 },
  metricCard: { backgroundColor: colors.surface1, borderRadius: radius.md, padding: spacing.md, borderWidth: 1, borderColor: colors.borderSubtle, marginBottom: spacing.sm },
  metricHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  metricLabel: { color: "#fff", fontWeight: "800", fontSize: 14 },
  metricScore: { fontWeight: "900", fontSize: 22, letterSpacing: -1 },
  metricBarBg: { height: 6, backgroundColor: colors.surface2, borderRadius: 3, marginTop: spacing.sm, overflow: "hidden" },
  metricBarFill: { height: "100%", borderRadius: 3 },
  metricNote: { color: colors.textSecondary, fontSize: 12, marginTop: spacing.sm, lineHeight: 16 },
  styleCard: { backgroundColor: colors.surface1, borderRadius: radius.lg, padding: spacing.lg, borderWidth: 1, borderColor: colors.borderSubtle, marginBottom: spacing.xl },
  styleSubLabel: { color: colors.textTertiary, fontSize: 9, letterSpacing: 2, fontWeight: "800", marginBottom: spacing.sm },
  colorRow: { flexDirection: "row", flexWrap: "wrap", gap: 6 },
  colorChip: { paddingHorizontal: 10, paddingVertical: 6, borderRadius: radius.pill, backgroundColor: colors.surface2, borderWidth: 1, borderColor: colors.borderSubtle },
  colorChipAvoid: { borderColor: "rgba(255,59,48,0.4)" },
  colorChipText: { color: "#fff", fontSize: 12, fontWeight: "700" },
  jewelryRow: { flexDirection: "row", gap: 8, alignItems: "flex-start", marginTop: spacing.md, paddingTop: spacing.md, borderTopWidth: 1, borderTopColor: colors.borderSubtle },
  jewelryText: { color: "#fff", flex: 1, fontSize: 13, lineHeight: 18 },
  accBullet: { flexDirection: "row", gap: 8, marginTop: 6, alignItems: "flex-start" },
  accDot: { width: 5, height: 5, borderRadius: 3, backgroundColor: colors.gold, marginTop: 7 },
  accText: { color: "#fff", flex: 1, fontSize: 13, lineHeight: 18 },
  cta: { backgroundColor: colors.ice, paddingVertical: 18, borderRadius: radius.pill, alignItems: "center", marginTop: spacing.xl },
  ctaText: { color: "#000", fontWeight: "900", letterSpacing: 3, fontSize: 14 },
  celebCard: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
    backgroundColor: colors.surface1,
    borderRadius: radius.lg,
    padding: spacing.md,
    borderWidth: 1,
    borderColor: "rgba(212,175,55,0.25)",
    marginBottom: spacing.sm,
  },
  celebRank: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: "rgba(212,175,55,0.15)",
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: "rgba(212,175,55,0.4)",
  },
  celebRankText: { color: colors.gold, fontWeight: "900", fontSize: 12 },
  celebHeader: { flexDirection: "row", alignItems: "baseline", gap: 6 },
  celebName: { color: "#fff", fontSize: 15, fontWeight: "900" },
  celebIndustry: { color: colors.textTertiary, fontSize: 10, fontWeight: "700", letterSpacing: 1 },
  celebShared: { color: colors.textSecondary, fontSize: 12, marginTop: 2, lineHeight: 16 },
  matchBarBg: { height: 4, backgroundColor: colors.surface2, borderRadius: 2, marginTop: 6, overflow: "hidden" },
  matchBarFill: { height: "100%", borderRadius: 2 },
  matchPct: { color: colors.gold, fontWeight: "900", fontSize: 16, minWidth: 40, textAlign: "right" },
});
