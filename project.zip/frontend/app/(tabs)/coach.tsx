import { useFocusEffect } from "expo-router";
import { useCallback, useRef, useState } from "react";
import {
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";

import { colors, radius, spacing } from "@/src/theme";
import { apiFetch, useAuth } from "@/src/auth/AuthContext";

type Msg = { id: string; role: "user" | "assistant"; content: string; created_at: string };

const QUICK_PROMPTS = [
  "How do I fix my jawline?",
  "Best skincare for oily skin?",
  "What hairstyle suits me?",
  "How to grow a beard faster?",
];

export default function CoachScreen() {
  const { token } = useAuth();
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const [loading, setLoading] = useState(true);
  const scrollRef = useRef<ScrollView>(null);

  const load = useCallback(async () => {
    if (!token) return;
    setLoading(true);
    try {
      const list = await apiFetch<Msg[]>("/chat/history", { method: "GET" }, token);
      setMessages(list);
      setTimeout(() => scrollRef.current?.scrollToEnd({ animated: false }), 100);
    } catch {
      /* ignore */
    } finally {
      setLoading(false);
    }
  }, [token]);

  useFocusEffect(useCallback(() => { load(); }, [load]));

  const send = async (text: string) => {
    if (!token || !text.trim() || sending) return;
    setSending(true);
    const optimistic: Msg = {
      id: `tmp-${Date.now()}`,
      role: "user",
      content: text,
      created_at: new Date().toISOString(),
    };
    setMessages((prev) => [...prev, optimistic]);
    setInput("");
    setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 50);
    try {
      const res = await apiFetch<{ user_message: Msg; assistant_message: Msg }>(
        "/chat/message",
        { method: "POST", body: JSON.stringify({ message: text }) },
        token,
      );
      setMessages((prev) => [
        ...prev.filter((m) => m.id !== optimistic.id),
        res.user_message,
        res.assistant_message,
      ]);
      setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 50);
    } catch (e: any) {
      setMessages((prev) => [
        ...prev,
        {
          id: `err-${Date.now()}`,
          role: "assistant",
          content: `⚠️ ${e.message || "Coach unavailable. Try again."}`,
          created_at: new Date().toISOString(),
        },
      ]);
    } finally {
      setSending(false);
    }
  };

  const clear = async () => {
    if (!token) return;
    await apiFetch("/chat/history", { method: "DELETE" }, token);
    setMessages([]);
  };

  return (
    <SafeAreaView style={styles.root} edges={["top"]}>
      <View style={styles.header}>
        <View style={{ flex: 1 }}>
          <Text style={styles.kicker}>MOGLABS // COACH</Text>
          <Text style={styles.title}>
            Ask <Text style={{ color: colors.ice }}>Mog</Text>.
          </Text>
        </View>
        {messages.length > 0 ? (
          <Pressable testID="coach-clear" onPress={clear} style={styles.clearBtn}>
            <Ionicons name="trash-outline" size={18} color={colors.textSecondary} />
          </Pressable>
        ) : null}
      </View>

      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
        keyboardVerticalOffset={Platform.OS === "ios" ? 90 : 0}
      >
        <ScrollView
          ref={scrollRef}
          style={{ flex: 1 }}
          contentContainerStyle={styles.scroll}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          {loading ? (
            <ActivityIndicator color={colors.ice} style={{ marginTop: spacing.xxxl }} />
          ) : messages.length === 0 ? (
            <View style={styles.emptyState}>
              <View style={styles.avatarMog}>
                <LinearGradient colors={[colors.ice, "#0088aa"]} style={StyleSheet.absoluteFill} />
                <Text style={styles.avatarMogText}>M</Text>
              </View>
              <Text style={styles.welcome}>
                I&apos;m Mog. Your private looksmaxxing coach.
              </Text>
              <Text style={styles.welcomeSub}>
                Ask anything — skin, hair, jawline, fitness, grooming, style. I&apos;ll be honest.
              </Text>

              <Text style={styles.quickLabel}>TRY ASKING</Text>
              <View style={styles.quickGrid}>
                {QUICK_PROMPTS.map((p) => (
                  <Pressable
                    key={p}
                    testID={`prompt-${p.slice(0, 12)}`}
                    style={styles.quickChip}
                    onPress={() => send(p)}
                  >
                    <Text style={styles.quickChipText}>{p}</Text>
                  </Pressable>
                ))}
              </View>
            </View>
          ) : (
            <>
              {messages.map((m) => (
                <View
                  key={m.id}
                  testID={`msg-${m.role}`}
                  style={[
                    styles.bubbleRow,
                    m.role === "user" ? styles.bubbleRight : styles.bubbleLeft,
                  ]}
                >
                  {m.role === "assistant" ? (
                    <View style={styles.miniAvatar}>
                      <Text style={styles.miniAvatarText}>M</Text>
                    </View>
                  ) : null}
                  <View
                    style={[
                      styles.bubble,
                      m.role === "user" ? styles.userBubble : styles.assistantBubble,
                    ]}
                  >
                    <Text
                      style={[
                        styles.bubbleText,
                        m.role === "user" && { color: "#000" },
                      ]}
                    >
                      {m.content}
                    </Text>
                  </View>
                </View>
              ))}
              {sending ? (
                <View style={[styles.bubbleRow, styles.bubbleLeft]}>
                  <View style={styles.miniAvatar}>
                    <Text style={styles.miniAvatarText}>M</Text>
                  </View>
                  <View style={[styles.bubble, styles.assistantBubble, styles.typingBubble]}>
                    <ActivityIndicator color={colors.ice} size="small" />
                    <Text style={styles.typingText}>thinking…</Text>
                  </View>
                </View>
              ) : null}
            </>
          )}
          <View style={{ height: 120 }} />
        </ScrollView>

        <View style={styles.inputBar}>
          <TextInput
            testID="coach-input"
            style={styles.input}
            placeholder="Ask Mog anything…"
            placeholderTextColor={colors.textTertiary}
            value={input}
            onChangeText={setInput}
            onSubmitEditing={() => send(input)}
            returnKeyType="send"
            blurOnSubmit={false}
            multiline
            maxLength={2000}
          />
          <Pressable
            testID="coach-send"
            onPress={() => send(input)}
            disabled={!input.trim() || sending}
            style={[
              styles.sendBtn,
              (!input.trim() || sending) && { opacity: 0.4 },
            ]}
          >
            <Ionicons name="arrow-up" size={20} color="#000" />
          </Pressable>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  header: { flexDirection: "row", alignItems: "flex-start", paddingHorizontal: spacing.xl, paddingTop: spacing.sm },
  kicker: { color: colors.ice, letterSpacing: 3, fontSize: 11, fontWeight: "800", marginBottom: spacing.sm },
  title: { color: "#fff", fontSize: 38, fontWeight: "900", letterSpacing: -1.5, lineHeight: 42, marginBottom: spacing.lg },
  clearBtn: { padding: 10, borderRadius: 999, backgroundColor: colors.surface1, borderWidth: 1, borderColor: colors.borderSubtle, marginTop: spacing.lg },
  scroll: { paddingHorizontal: spacing.lg, paddingTop: spacing.md },
  emptyState: { alignItems: "center", paddingTop: spacing.xl, paddingHorizontal: spacing.md },
  avatarMog: {
    width: 84,
    height: 84,
    borderRadius: 42,
    overflow: "hidden",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: spacing.lg,
    borderWidth: 2,
    borderColor: colors.ice,
  },
  avatarMogText: { color: "#000", fontWeight: "900", fontSize: 36 },
  welcome: { color: "#fff", fontSize: 22, fontWeight: "900", textAlign: "center", marginBottom: spacing.sm, letterSpacing: -0.5 },
  welcomeSub: { color: colors.textSecondary, fontSize: 14, textAlign: "center", lineHeight: 20, marginBottom: spacing.xxl },
  quickLabel: { color: colors.textTertiary, fontSize: 10, letterSpacing: 3, fontWeight: "800", marginBottom: spacing.md },
  quickGrid: { gap: spacing.sm, width: "100%" },
  quickChip: { backgroundColor: colors.surface1, borderWidth: 1, borderColor: colors.borderSubtle, borderRadius: radius.lg, paddingVertical: spacing.md, paddingHorizontal: spacing.lg },
  quickChipText: { color: "#fff", fontSize: 14, fontWeight: "600" },
  bubbleRow: { flexDirection: "row", marginBottom: spacing.md, alignItems: "flex-end", gap: 8 },
  bubbleLeft: { justifyContent: "flex-start" },
  bubbleRight: { justifyContent: "flex-end" },
  miniAvatar: { width: 28, height: 28, borderRadius: 14, backgroundColor: colors.ice, alignItems: "center", justifyContent: "center" },
  miniAvatarText: { color: "#000", fontWeight: "900", fontSize: 13 },
  bubble: { maxWidth: "82%", paddingHorizontal: spacing.md, paddingVertical: spacing.md, borderRadius: radius.lg },
  userBubble: { backgroundColor: colors.ice, borderBottomRightRadius: 4 },
  assistantBubble: { backgroundColor: colors.surface1, borderWidth: 1, borderColor: colors.borderSubtle, borderBottomLeftRadius: 4 },
  bubbleText: { color: "#fff", fontSize: 15, lineHeight: 22 },
  typingBubble: { flexDirection: "row", alignItems: "center", gap: 10 },
  typingText: { color: colors.textSecondary, fontSize: 13 },
  inputBar: {
    flexDirection: "row",
    alignItems: "flex-end",
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    gap: spacing.sm,
    backgroundColor: "rgba(5,5,5,0.95)",
    borderTopWidth: 1,
    borderTopColor: colors.borderSubtle,
    marginBottom: 80,
  },
  input: {
    flex: 1,
    backgroundColor: colors.surface1,
    borderRadius: 22,
    borderWidth: 1,
    borderColor: colors.borderSubtle,
    paddingHorizontal: spacing.lg,
    paddingVertical: 12,
    color: "#fff",
    fontSize: 15,
    maxHeight: 120,
  },
  sendBtn: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: colors.ice,
    alignItems: "center",
    justifyContent: "center",
  },
});
