import { useFocusEffect, useRouter } from "expo-router";
import { useCallback, useState } from "react";
import { ScrollView, StyleSheet, Text, View, Pressable, ActivityIndicator } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";

import { colors, radius, spacing } from "@/src/theme";
import { apiFetch, useAuth } from "@/src/auth/AuthContext";

type Point = { scan_id: string; created_at: string; overall_score: number; symmetry_score: number };
type Progress = { direction: string; delta: number; points: Point[] };

export default function ProgressScreen() {
  const router = useRouter();
  const { token } = useAuth();
  const [data, setData] = useState<Progress | null>(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    if (!token) return;
    setLoading(true);
    try {
      const res = await apiFetch<Progress>("/progress", { method: "GET" }, token);
      setData(res);
    } catch {
      setData(null);
    } finally {
      setLoading(false);
    }
  }, [token]);

  useFocusEffect(useCallback(() => { load(); }, [load]));

  const direction = data?.direction || "insufficient";
  const arrowColor =
    direction === "ascending" ? colors.ascend : direction === "descending" ? colors.descend : colors.textSecondary;
  const arrowIcon =
    direction === "ascending" ? "trending-up" : direction === "descending" ? "trending-down" : "remove";

  const points = data?.points || [];
  const maxScore = Math.max(10, ...points.map((p) => p.overall_score));
  const minScore = Math.min(0, ...points.map((p) => p.overall_score));
  const range = Math.max(1, maxScore - minScore);

  return (
    <SafeAreaView style={styles.root} edges={["top"]}>
      <ScrollView contentContainerStyle={styles.scroll} testID="progress-screen" showsVerticalScrollIndicator={false}>
        <Text style={styles.kicker}>MOGLABS // PROGRESS</Text>
        <Text style={styles.title}>Your trajectory.</Text>

        {loading ? (
          <ActivityIndicator color={colors.ice} style={{ marginTop: spacing.xxxl }} />
        ) : (
          <>
            <View style={styles.trendCard}>
              <View style={{ flexDirection: "row", alignItems: "center", gap: spacing.md }}>
                <Ionicons name={arrowIcon as any} size={36} color={arrowColor} />
                <View>
                  <Text style={styles.trendLabel}>CURRENT TREND</Text>
                  <Text style={[styles.trendValue, { color: arrowColor }]}>
                    {direction.toUpperCase()}
                  </Text>
                </View>
              </View>
              {data && data.points.length >= 2 ? (
                <Text style={styles.trendDelta}>
                  {data.delta > 0 ? "+" : ""}
                  {data.delta.toFixed(2)} pts
                </Text>
              ) : null}
            </View>

            <Text style={styles.section}>OVERALL SCORE OVER TIME</Text>
            <View style={styles.chartCard}>
              {points.length < 2 ? (
                <Text style={styles.empty}>
                  Run at least 2 scans to see your ascent chart.
                </Text>
              ) : (
                <View style={styles.chart}>
                  {points.map((p, i) => {
                    const h = ((p.overall_score - minScore) / range) * 100;
                    return (
                      <View key={p.scan_id} style={styles.barCol}>
                        <View style={[styles.bar, { height: `${Math.max(6, h)}%` }]}>
                          <LinearGradient
                            colors={[colors.ice, "rgba(0,229,255,0.2)"]}
                            style={StyleSheet.absoluteFill}
                          />
                        </View>
                        <Text style={styles.barLabel}>{p.overall_score.toFixed(1)}</Text>
                        {i === 0 || i === points.length - 1 ? (
                          <Text style={styles.barDate}>
                            {new Date(p.created_at).toLocaleDateString(undefined, { month: "short", day: "numeric" })}
                          </Text>
                        ) : null}
                      </View>
                    );
                  })}
                </View>
              )}
            </View>

            <Text style={styles.section}>SCAN HISTORY</Text>
            {points.length === 0 ? (
              <Text style={styles.empty}>No scans yet.</Text>
            ) : (
              [...points].reverse().map((p) => (
                <Pressable
                  key={p.scan_id}
                  testID={`history-${p.scan_id}`}
                  style={styles.row}
                  onPress={() => router.push({ pathname: "/scan-result/[id]", params: { id: p.scan_id } })}
                >
                  <View style={{ flex: 1 }}>
                    <Text style={styles.rowDate}>{new Date(p.created_at).toLocaleString()}</Text>
                    <Text style={styles.rowSub}>Symmetry {p.symmetry_score.toFixed(1)}</Text>
                  </View>
                  <Text style={styles.rowScore}>{p.overall_score.toFixed(1)}</Text>
                  <Ionicons name="chevron-forward" size={20} color={colors.textTertiary} />
                </Pressable>
              ))
            )}
          </>
        )}

        <View style={{ height: 120 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  scroll: { padding: spacing.xl },
  kicker: { color: colors.ice, letterSpacing: 3, fontSize: 11, fontWeight: "800", marginBottom: spacing.sm, marginTop: spacing.sm },
  title: { color: "#fff", fontSize: 38, fontWeight: "900", letterSpacing: -1.5, marginBottom: spacing.xl, lineHeight: 42 },
  trendCard: {
    backgroundColor: colors.surface1,
    borderRadius: radius.xl,
    padding: spacing.xl,
    borderWidth: 1,
    borderColor: colors.borderSubtle,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: spacing.xxl,
  },
  trendLabel: { color: colors.textTertiary, letterSpacing: 2, fontSize: 10, fontWeight: "800" },
  trendValue: { fontSize: 24, fontWeight: "900", letterSpacing: -1, marginTop: 2 },
  trendDelta: { color: "#fff", fontSize: 16, fontWeight: "800" },
  section: { color: colors.textTertiary, fontSize: 10, letterSpacing: 3, fontWeight: "800", marginBottom: spacing.md },
  chartCard: {
    backgroundColor: colors.surface1,
    borderRadius: radius.xl,
    padding: spacing.lg,
    borderWidth: 1,
    borderColor: colors.borderSubtle,
    height: 220,
    marginBottom: spacing.xxl,
  },
  chart: { flex: 1, flexDirection: "row", alignItems: "flex-end", gap: 8, paddingTop: spacing.md },
  barCol: { flex: 1, alignItems: "center", height: "100%", justifyContent: "flex-end" },
  bar: { width: "70%", maxWidth: 28, borderRadius: 6, overflow: "hidden", minHeight: 6 },
  barLabel: { color: "#fff", fontSize: 10, fontWeight: "700", marginTop: 6 },
  barDate: { color: colors.textTertiary, fontSize: 9, marginTop: 2 },
  empty: { color: colors.textSecondary, textAlign: "center", marginTop: spacing.xl, fontSize: 13 },
  row: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
    padding: spacing.md,
    backgroundColor: colors.surface1,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.borderSubtle,
    marginBottom: spacing.sm,
  },
  rowDate: { color: "#fff", fontSize: 13, fontWeight: "700" },
  rowSub: { color: colors.textSecondary, fontSize: 11, marginTop: 2 },
  rowScore: { color: colors.ice, fontSize: 22, fontWeight: "900" },
});
