import { useRouter } from "expo-router";
import { Alert, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";

import { colors, radius, spacing } from "@/src/theme";
import { useAuth } from "@/src/auth/AuthContext";

export default function ProfileScreen() {
  const router = useRouter();
  const { user, logout } = useAuth();

  const handleLogout = async () => {
    Alert.alert("Log out", "Are you sure?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Log out",
        style: "destructive",
        onPress: async () => {
          await logout();
          router.replace("/");
        },
      },
    ]);
  };

  return (
    <SafeAreaView style={styles.root} edges={["top"]}>
      <ScrollView contentContainerStyle={styles.scroll} testID="profile-screen" showsVerticalScrollIndicator={false}>
        <Text style={styles.kicker}>MOGLABS // PROFILE</Text>

        <View style={styles.identity}>
          <View style={styles.avatar}>
            <Text style={styles.avatarText}>
              {(user?.name?.[0] || user?.email?.[0] || "?").toUpperCase()}
            </Text>
          </View>
          <Text style={styles.name}>{user?.name || "Subject"}</Text>
          <Text style={styles.email}>{user?.email}</Text>
          <View style={styles.badgeGold}>
            <Ionicons name="diamond" size={14} color="#000" />
            <Text style={styles.badgeGoldText}>FULL ACCESS</Text>
          </View>
        </View>

        <Text style={styles.section}>ACCOUNT</Text>

        <Pressable style={styles.row} onPress={() => router.push("/(tabs)/progress")}>
          <Ionicons name="trending-up" size={20} color={colors.ice} />
          <Text style={styles.rowText}>My progress</Text>
          <Ionicons name="chevron-forward" size={18} color={colors.textTertiary} />
        </Pressable>

        <Pressable style={styles.row} onPress={() => router.push("/(tabs)/suggestions")}>
          <Ionicons name="sparkles" size={20} color={colors.ice} />
          <Text style={styles.rowText}>My recommendations</Text>
          <Ionicons name="chevron-forward" size={18} color={colors.textTertiary} />
        </Pressable>

        <Pressable testID="profile-logout" style={styles.row} onPress={handleLogout}>
          <Ionicons name="log-out" size={20} color={colors.descend} />
          <Text style={[styles.rowText, { color: colors.descend }]}>Log out</Text>
          <Ionicons name="chevron-forward" size={18} color={colors.textTertiary} />
        </Pressable>

        <Text style={styles.footer}>Moglabs · No ads, ever.</Text>
        <View style={{ height: 120 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  scroll: { padding: spacing.xl },
  kicker: { color: colors.ice, letterSpacing: 3, fontSize: 11, fontWeight: "800", marginBottom: spacing.xl, marginTop: spacing.sm },
  identity: { alignItems: "center", marginBottom: spacing.xxl },
  avatar: {
    width: 96,
    height: 96,
    borderRadius: 48,
    backgroundColor: colors.surface2,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 2,
    borderColor: colors.borderActive,
    marginBottom: spacing.md,
  },
  avatarText: { color: colors.ice, fontSize: 40, fontWeight: "900" },
  name: { color: "#fff", fontSize: 22, fontWeight: "900", textTransform: "capitalize" },
  email: { color: colors.textSecondary, fontSize: 13, marginTop: 4 },
  badgeGold: {
    flexDirection: "row",
    gap: 6,
    alignItems: "center",
    backgroundColor: colors.gold,
    paddingHorizontal: 14,
    paddingVertical: 6,
    borderRadius: radius.pill,
    marginTop: spacing.md,
  },
  badgeGoldText: { color: "#000", fontWeight: "900", letterSpacing: 2, fontSize: 11 },
  badgeFree: {
    backgroundColor: colors.surface2,
    paddingHorizontal: 14,
    paddingVertical: 6,
    borderRadius: radius.pill,
    marginTop: spacing.md,
    borderWidth: 1,
    borderColor: colors.borderSubtle,
  },
  badgeFreeText: { color: colors.textSecondary, fontWeight: "800", letterSpacing: 2, fontSize: 11 },
  upgradeCard: {
    borderRadius: radius.xl,
    overflow: "hidden",
    borderWidth: 1,
    borderColor: colors.gold,
    padding: spacing.xl,
    marginBottom: spacing.xxl,
  },
  upgradeRow: { flexDirection: "row", alignItems: "center", gap: spacing.lg },
  upgradeLabel: { color: colors.gold, fontSize: 10, letterSpacing: 3, fontWeight: "900" },
  upgradeTitle: { color: "#fff", fontSize: 22, fontWeight: "900", marginTop: 4 },
  upgradeSub: { color: colors.textSecondary, fontSize: 13, marginTop: 2 },
  section: { color: colors.textTertiary, fontSize: 10, letterSpacing: 3, fontWeight: "800", marginBottom: spacing.md },
  row: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
    paddingVertical: spacing.lg,
    paddingHorizontal: spacing.lg,
    backgroundColor: colors.surface1,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.borderSubtle,
    marginBottom: spacing.sm,
  },
  rowText: { color: "#fff", flex: 1, fontSize: 15, fontWeight: "700" },
  footer: { color: colors.textTertiary, textAlign: "center", marginTop: spacing.xxxl, fontSize: 11, letterSpacing: 1 },
});
