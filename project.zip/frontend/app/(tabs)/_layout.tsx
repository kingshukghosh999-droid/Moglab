import { Tabs } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { Platform, StyleSheet, View } from "react-native";
import { BlurView } from "expo-blur";

import { colors } from "@/src/theme";

export default function TabsLayout() {
  return (
    <Tabs
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: colors.ice,
        tabBarInactiveTintColor: colors.textTertiary,
        tabBarShowLabel: true,
        tabBarLabelStyle: {
          fontSize: 9,
          fontWeight: "700",
          letterSpacing: 1,
          marginBottom: 6,
        },
        tabBarStyle: {
          position: "absolute",
          left: 16,
          right: 16,
          bottom: Platform.OS === "ios" ? 24 : 16,
          height: 64,
          borderRadius: 24,
          borderTopWidth: 0,
          backgroundColor: "rgba(15,15,17,0.92)",
          borderWidth: 1,
          borderColor: colors.borderSubtle,
          elevation: 0,
          paddingTop: 8,
        },
        tabBarBackground: () => (
          <View style={StyleSheet.absoluteFill}>
            <BlurView intensity={40} tint="dark" style={StyleSheet.absoluteFill} />
          </View>
        ),
        tabBarIcon: ({ color, focused }) => {
          const name =
            route.name === "scan"
              ? "scan-circle"
              : route.name === "progress"
                ? "trending-up"
                : route.name === "suggestions"
                  ? "sparkles"
                  : route.name === "coach"
                    ? "chatbubble-ellipses"
                    : "person-circle";
          return (
            <Ionicons
              name={name as any}
              size={focused ? 26 : 22}
              color={color}
              style={focused ? { textShadowColor: colors.ice, textShadowRadius: 8 } : undefined}
            />
          );
        },
      })}
    >
      <Tabs.Screen name="scan" options={{ title: "SCAN" }} />
      <Tabs.Screen name="progress" options={{ title: "PROGRESS" }} />
      <Tabs.Screen name="coach" options={{ title: "COACH" }} />
      <Tabs.Screen name="suggestions" options={{ title: "GLOW UP" }} />
      <Tabs.Screen name="profile" options={{ title: "PROFILE" }} />
    </Tabs>
  );
}
