import { useRouter } from "expo-router";
import { useCallback, useEffect, useState } from "react";
import {
  ActivityIndicator,
  Image,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import * as ImagePicker from "expo-image-picker";
import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";

import { colors, radius, spacing } from "@/src/theme";
import { apiFetch, useAuth } from "@/src/auth/AuthContext";

type Scan = {
  id: string;
  overall_score: number;
  symmetry_score: number;
  created_at: string;
};

export default function ScanScreen() {
  const router = useRouter();
  const { token, user } = useAuth();
  const [picked, setPicked] = useState<string | null>(null);
  const [b64, setB64] = useState<string | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [recent, setRecent] = useState<Scan[]>([]);
  const [error, setError] = useState<string | null>(null);

  const loadRecent = useCallback(async () => {
    if (!token) return;
    try {
      const list = await apiFetch<Scan[]>("/scans", { method: "GET" }, token);
      setRecent(list.slice(0, 3));
    } catch {
      /* ignore */
    }
  }, [token]);

  useEffect(() => {
    loadRecent();
  }, [loadRecent]);

  const pickImage = async (useCamera: boolean) => {
    setError(null);
    const opts: ImagePicker.ImagePickerOptions = {
      mediaTypes: ["images"],
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.7,
      base64: true,
    };
    let result;
    if (useCamera) {
      const perm = await ImagePicker.requestCameraPermissionsAsync();
      if (!perm.granted) {
        setError("Camera access needed to scan your face.");
        return;
      }
      result = await ImagePicker.launchCameraAsync(opts);
    } else {
      result = await ImagePicker.launchImageLibraryAsync(opts);
    }
    if (result.canceled || !result.assets?.[0]) return;
    const asset = result.assets[0];
    setPicked(asset.uri);
    setB64(asset.base64 || null);
  };

  const analyze = async () => {
    if (!b64 || !token) {
      setError("Please select or take a selfie first.");
      return;
    }
    setAnalyzing(true);
    setError(null);
    try {
      const scan = await apiFetch<{ id: string }>(
        "/scans",
        { method: "POST", body: JSON.stringify({ image_b64: b64 }) },
        token,
      );
      setPicked(null);
      setB64(null);
      await loadRecent();
      router.push({ pathname: "/scan-result/[id]", params: { id: scan.id } });
    } catch (e: any) {
      setError(e.message || "Analysis failed. Try a clearer front-facing selfie.");
    } finally {
      setAnalyzing(false);
    }
  };

  return (
    <SafeAreaView style={styles.root} edges={["top"]}>
      <ScrollView
        contentContainerStyle={styles.scroll}
        showsVerticalScrollIndicator={false}
        testID="scan-screen"
      >
        <View style={styles.header}>
          <View>
            <Text style={styles.kicker}>MOGLABS // SCAN</Text>
            <Text style={styles.title}>
              Hello,{"\n"}
              <Text style={{ color: colors.ice }}>{user?.name || "subject"}</Text>.
            </Text>
          </View>
        </View>

        <View style={styles.previewCard}>
          {picked ? (
            <Image source={{ uri: picked }} style={styles.preview} resizeMode="cover" />
          ) : (
            <View style={styles.placeholder}>
              <View style={styles.faceGrid}>
                <Ionicons name="scan-outline" size={120} color={colors.iceGlow} />
              </View>
              <Text style={styles.placeholderText}>
                Front-facing, neutral expression, good lighting.
              </Text>
            </View>
          )}
          <LinearGradient
            pointerEvents="none"
            colors={["transparent", "rgba(5,5,5,0.7)"]}
            style={styles.previewOverlay}
          />
        </View>

        {error ? (
          <Text style={styles.error} testID="scan-error">
            {error}
          </Text>
        ) : null}

        <View style={styles.row}>
          <Pressable
            testID="scan-pick-library"
            style={styles.secondary}
            onPress={() => pickImage(false)}
          >
            <Ionicons name="images" size={18} color="#fff" />
            <Text style={styles.secondaryText}>UPLOAD</Text>
          </Pressable>
          <Pressable
            testID="scan-pick-camera"
            style={styles.secondary}
            onPress={() => pickImage(true)}
          >
            <Ionicons name="camera" size={18} color="#fff" />
            <Text style={styles.secondaryText}>CAMERA</Text>
          </Pressable>
        </View>

        <Pressable
          testID="scan-analyze"
          onPress={analyze}
          disabled={!b64 || analyzing}
          style={({ pressed }) => [
            styles.cta,
            (!b64 || analyzing) && { opacity: 0.4 },
            pressed && { opacity: 0.85 },
          ]}
        >
          {analyzing ? (
            <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
              <ActivityIndicator color="#000" />
              <Text style={styles.ctaText}>ANALYZING…</Text>
            </View>
          ) : (
            <Text style={styles.ctaText}>ANALYZE FACE</Text>
          )}
        </Pressable>

        <Text style={styles.section}>RECENT SCANS</Text>
        {recent.length === 0 ? (
          <Text style={styles.empty}>No scans yet — run your first analysis above.</Text>
        ) : (
          recent.map((s) => (
            <Pressable
              key={s.id}
              testID={`recent-scan-${s.id}`}
              style={styles.recentRow}
              onPress={() => router.push({ pathname: "/scan-result/[id]", params: { id: s.id } })}
            >
              <View style={{ flex: 1 }}>
                <Text style={styles.recentLabel}>{new Date(s.created_at).toLocaleDateString()}</Text>
                <Text style={styles.recentSub}>Symmetry {s.symmetry_score.toFixed(1)} / 10</Text>
              </View>
              <Text style={styles.recentScore}>{s.overall_score.toFixed(1)}</Text>
              <Ionicons name="chevron-forward" size={20} color={colors.textTertiary} />
            </Pressable>
          ))
        )}

        <View style={{ height: 120 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  scroll: { padding: spacing.xl },
  header: { marginTop: spacing.sm, marginBottom: spacing.xl },
  kicker: { color: colors.ice, letterSpacing: 3, fontSize: 11, fontWeight: "800", marginBottom: spacing.sm },
  title: { color: "#fff", fontSize: 38, fontWeight: "900", letterSpacing: -1.5, lineHeight: 42 },
  previewCard: {
    aspectRatio: 1,
    borderRadius: radius.xl,
    overflow: "hidden",
    borderWidth: 1,
    borderColor: colors.borderActive,
    backgroundColor: colors.surface1,
    marginBottom: spacing.lg,
  },
  preview: { width: "100%", height: "100%" },
  previewOverlay: { ...StyleSheet.absoluteFillObject },
  placeholder: { flex: 1, alignItems: "center", justifyContent: "center", padding: spacing.xl },
  faceGrid: { padding: spacing.xl, borderWidth: 1, borderColor: colors.borderActive, borderRadius: radius.xl, marginBottom: spacing.lg },
  placeholderText: { color: colors.textSecondary, textAlign: "center", fontSize: 13 },
  error: { color: colors.descend, marginBottom: spacing.md, fontSize: 13 },
  row: { flexDirection: "row", gap: spacing.md, marginBottom: spacing.md },
  secondary: {
    flex: 1,
    backgroundColor: colors.surface2,
    paddingVertical: 16,
    borderRadius: radius.pill,
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
    gap: 8,
    borderWidth: 1,
    borderColor: colors.borderSubtle,
  },
  secondaryText: { color: "#fff", fontWeight: "800", letterSpacing: 2, fontSize: 12 },
  cta: {
    backgroundColor: colors.ice,
    paddingVertical: 18,
    borderRadius: radius.pill,
    alignItems: "center",
    shadowColor: colors.ice,
    shadowOpacity: 0.5,
    shadowRadius: 16,
    marginTop: spacing.md,
    marginBottom: spacing.xxl,
  },
  ctaText: { color: "#000", fontWeight: "900", letterSpacing: 3, fontSize: 14 },
  section: { color: colors.textTertiary, fontSize: 10, letterSpacing: 3, fontWeight: "800", marginBottom: spacing.md },
  empty: { color: colors.textSecondary, fontSize: 13, marginBottom: spacing.lg },
  recentRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
    backgroundColor: colors.surface1,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.borderSubtle,
    marginBottom: spacing.sm,
  },
  recentLabel: { color: "#fff", fontWeight: "700", fontSize: 14 },
  recentSub: { color: colors.textSecondary, fontSize: 12, marginTop: 2 },
  recentScore: { color: colors.ice, fontSize: 24, fontWeight: "900", letterSpacing: -1 },
});
