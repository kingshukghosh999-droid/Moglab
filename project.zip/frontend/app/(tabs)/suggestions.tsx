import { useFocusEffect, useRouter } from "expo-router";
import { useCallback, useState } from "react";
import {
  ActivityIndicator,
  Image,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";

import { colors, radius, spacing } from "@/src/theme";
import { apiFetch, useAuth } from "@/src/auth/AuthContext";

type Product = { name: string; brand: string; price_inr: string; why: string };
type StyleRec = {
  outfit_colors?: string[];
  colors_to_avoid?: string[];
  jewelry?: string;
  accessories?: string[];
};
type Scan = {
  id: string;
  tier_label?: string;
  face_shape: string;
  hairline_type: string;
  skin_undertone?: string;
  skin_products?: Product[];
  hair_products?: Product[];
  hairstyle_suggestions: string[];
  style_recommendations?: StyleRec;
  created_at: string;
};

export default function SuggestionsScreen() {
  const router = useRouter();
  const { token } = useAuth();
  const [scan, setScan] = useState<Scan | null>(null);
  const [loading, setLoading] = useState(true);
  const [hairstylePreview, setHairstylePreview] = useState<{ name: string; b64: string } | null>(null);
  const [generating, setGenerating] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<"skin" | "hair" | "style">("skin");

  const load = useCallback(async () => {
    if (!token) return;
    setLoading(true);
    try {
      const list = await apiFetch<Scan[]>("/scans", { method: "GET" }, token);
      setScan(list[0] || null);
    } catch {
      setScan(null);
    } finally {
      setLoading(false);
    }
  }, [token]);

  useFocusEffect(useCallback(() => { load(); setHairstylePreview(null); }, [load]));

  const previewHairstyle = async (name: string) => {
    if (!scan || !token) return;
    setGenerating(name);
    setHairstylePreview(null);
    try {
      const res = await apiFetch<{ hairstyle: string; image_b64: string }>(
        "/hairstyle/preview",
        { method: "POST", body: JSON.stringify({ scan_id: scan.id, hairstyle: name }) },
        token,
      );
      setHairstylePreview({ name: res.hairstyle, b64: res.image_b64 });
    } catch (e: any) {
      console.log("Hairstyle preview error", e?.message);
    } finally {
      setGenerating(null);
    }
  };

  const style = scan?.style_recommendations || {};
  const products = activeTab === "skin" ? (scan?.skin_products || []) : (scan?.hair_products || []);

  return (
    <SafeAreaView style={styles.root} edges={["top"]}>
      <ScrollView contentContainerStyle={styles.scroll} testID="suggestions-screen" showsVerticalScrollIndicator={false}>
        <Text style={styles.kicker}>MOGLABS // GLOW UP</Text>
        <Text style={styles.title}>Your India{"\n"}playbook.</Text>

        {loading ? (
          <ActivityIndicator color={colors.ice} style={{ marginTop: spacing.xxxl }} />
        ) : !scan ? (
          <View style={styles.emptyCard}>
            <Ionicons name="scan-outline" size={48} color={colors.iceGlow} />
            <Text style={styles.emptyText}>Run your first scan to unlock your playbook.</Text>
            <Pressable style={styles.scanCta} onPress={() => router.push("/(tabs)/scan")}>
              <Text style={styles.scanCtaText}>GO TO SCAN</Text>
            </Pressable>
          </View>
        ) : (
          <>
            <View style={styles.meta}>
              <View style={styles.metaPill}>
                <Text style={styles.metaPillLabel}>FACE</Text>
                <Text style={styles.metaPillValue}>{scan.face_shape}</Text>
              </View>
              <View style={styles.metaPill}>
                <Text style={styles.metaPillLabel}>HAIRLINE</Text>
                <Text style={styles.metaPillValue}>{scan.hairline_type}</Text>
              </View>
              <View style={styles.metaPill}>
                <Text style={styles.metaPillLabel}>SKIN</Text>
                <Text style={styles.metaPillValue}>{scan.skin_undertone || "neutral"}</Text>
              </View>
            </View>

            {/* Tab switcher */}
            <View style={styles.tabSwitch}>
              {(["skin", "hair", "style"] as const).map((t) => (
                <Pressable
                  key={t}
                  testID={`tab-${t}`}
                  onPress={() => setActiveTab(t)}
                  style={[styles.tabBtn, activeTab === t && styles.tabBtnActive]}
                >
                  <Text style={[styles.tabBtnText, activeTab === t && styles.tabBtnTextActive]}>
                    {t === "skin" ? "SKIN" : t === "hair" ? "HAIR" : "STYLE"}
                  </Text>
                </Pressable>
              ))}
            </View>

            {activeTab !== "style" ? (
              <>
                <Text style={styles.section}>
                  {activeTab === "skin" ? "SKIN PRODUCTS — INDIA" : "HAIR PRODUCTS — INDIA"}
                </Text>
                {products.length === 0 ? (
                  <Text style={styles.empty}>No products yet — re-scan with the latest engine.</Text>
                ) : (
                  products.map((p, i) => (
                    <View key={i} style={styles.productCard} testID={`product-${i}`}>
                      <View style={styles.productHeader}>
                        <View style={{ flex: 1 }}>
                          <Text style={styles.brand}>{p.brand}</Text>
                          <Text style={styles.productName}>{p.name}</Text>
                        </View>
                        <View style={styles.priceTag}>
                          <Text style={styles.priceText}>{p.price_inr}</Text>
                        </View>
                      </View>
                      <View style={styles.whyRow}>
                        <Ionicons name="checkmark-circle" size={14} color={colors.ice} />
                        <Text style={styles.whyText}>{p.why}</Text>
                      </View>
                    </View>
                  ))
                )}

                {activeTab === "hair" ? (
                  <>
                    <Text style={styles.section}>HAIRSTYLES FOR YOUR FACE</Text>
                    <View style={styles.hairGrid}>
                      {scan.hairstyle_suggestions.map((h) => (
                        <Pressable
                          key={h}
                          testID={`hairstyle-${h}`}
                          onPress={() => previewHairstyle(h)}
                          style={styles.hairCard}
                        >
                          <Ionicons name="cut" size={22} color={colors.ice} />
                          <Text style={styles.hairName}>{h}</Text>
                          {generating === h ? (
                            <ActivityIndicator color={colors.ice} size="small" />
                          ) : (
                            <Text style={styles.hairAction}>PREVIEW ↗</Text>
                          )}
                        </Pressable>
                      ))}
                    </View>
                    {hairstylePreview ? (
                      <View style={styles.previewCard}>
                        <Text style={styles.previewLabel}>{hairstylePreview.name.toUpperCase()}</Text>
                        <Image
                          source={{ uri: `data:image/png;base64,${hairstylePreview.b64}` }}
                          style={styles.previewImg}
                          resizeMode="cover"
                        />
                      </View>
                    ) : null}
                  </>
                ) : null}
              </>
            ) : (
              <>
                {style.outfit_colors && style.outfit_colors.length > 0 ? (
                  <>
                    <Text style={styles.section}>YOUR COLOR PALETTE</Text>
                    <View style={styles.styleCard}>
                      <Text style={styles.styleSubLabel}>WEAR THESE</Text>
                      <View style={styles.colorRow}>
                        {style.outfit_colors.map((c) => (
                          <View key={c} style={styles.colorChip}>
                            <Text style={styles.colorChipText}>{c}</Text>
                          </View>
                        ))}
                      </View>
                      {style.colors_to_avoid && style.colors_to_avoid.length > 0 ? (
                        <>
                          <Text style={[styles.styleSubLabel, { marginTop: spacing.md }]}>AVOID</Text>
                          <View style={styles.colorRow}>
                            {style.colors_to_avoid.map((c) => (
                              <View key={c} style={[styles.colorChip, styles.colorChipAvoid]}>
                                <Text style={[styles.colorChipText, { color: colors.descend }]}>{c}</Text>
                              </View>
                            ))}
                          </View>
                        </>
                      ) : null}
                    </View>

                    {style.jewelry ? (
                      <View style={styles.jewelryCard}>
                        <View style={styles.jewelryIconWrap}>
                          <Ionicons name="diamond" size={24} color={colors.gold} />
                        </View>
                        <View style={{ flex: 1 }}>
                          <Text style={styles.jewelryLabel}>JEWELRY TONE</Text>
                          <Text style={styles.jewelryText}>{style.jewelry}</Text>
                        </View>
                      </View>
                    ) : null}

                    {style.accessories && style.accessories.length > 0 ? (
                      <>
                        <Text style={styles.section}>ACCESSORY UPGRADES</Text>
                        {style.accessories.map((a, i) => (
                          <View key={i} style={styles.accCard}>
                            <View style={styles.accBadge}>
                              <Text style={styles.accBadgeText}>{i + 1}</Text>
                            </View>
                            <Text style={styles.accText}>{a}</Text>
                          </View>
                        ))}
                      </>
                    ) : null}
                  </>
                ) : (
                  <Text style={styles.empty}>No style data on this scan — re-scan with latest engine.</Text>
                )}
              </>
            )}
          </>
        )}

        <View style={{ height: 120 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  scroll: { padding: spacing.xl },
  kicker: { color: colors.ice, letterSpacing: 3, fontSize: 11, fontWeight: "800", marginBottom: spacing.sm, marginTop: spacing.sm },
  title: { color: "#fff", fontSize: 38, fontWeight: "900", letterSpacing: -1.5, marginBottom: spacing.xl, lineHeight: 42 },
  emptyCard: { alignItems: "center", padding: spacing.xxxl, gap: spacing.lg },
  emptyText: { color: colors.textSecondary, textAlign: "center", fontSize: 14 },
  scanCta: { backgroundColor: colors.ice, paddingHorizontal: spacing.xxl, paddingVertical: 14, borderRadius: radius.pill, marginTop: spacing.md },
  scanCtaText: { color: "#000", fontWeight: "900", letterSpacing: 2 },
  meta: { flexDirection: "row", gap: spacing.sm, marginBottom: spacing.lg },
  metaPill: { flex: 1, backgroundColor: colors.surface1, borderRadius: radius.lg, padding: spacing.md, borderWidth: 1, borderColor: colors.borderSubtle },
  metaPillLabel: { color: colors.textTertiary, fontSize: 9, letterSpacing: 2, fontWeight: "800" },
  metaPillValue: { color: "#fff", fontSize: 14, fontWeight: "900", marginTop: 4, textTransform: "capitalize" },
  tabSwitch: { flexDirection: "row", backgroundColor: colors.surface1, borderRadius: radius.pill, padding: 4, marginBottom: spacing.xl, borderWidth: 1, borderColor: colors.borderSubtle },
  tabBtn: { flex: 1, paddingVertical: 10, alignItems: "center", borderRadius: radius.pill },
  tabBtnActive: { backgroundColor: colors.ice },
  tabBtnText: { color: colors.textSecondary, fontWeight: "800", letterSpacing: 1.5, fontSize: 12 },
  tabBtnTextActive: { color: "#000" },
  section: { color: colors.textTertiary, fontSize: 10, letterSpacing: 3, fontWeight: "800", marginBottom: spacing.md, marginTop: spacing.md },
  empty: { color: colors.textSecondary, textAlign: "center", fontSize: 13 },
  productCard: {
    backgroundColor: colors.surface1,
    borderRadius: radius.lg,
    padding: spacing.md,
    borderWidth: 1,
    borderColor: colors.borderSubtle,
    marginBottom: spacing.sm,
  },
  productHeader: { flexDirection: "row", alignItems: "flex-start", gap: spacing.md },
  brand: { color: colors.ice, fontSize: 10, fontWeight: "900", letterSpacing: 2 },
  productName: { color: "#fff", fontSize: 15, fontWeight: "800", marginTop: 4 },
  priceTag: { backgroundColor: "rgba(0,229,255,0.12)", paddingHorizontal: 10, paddingVertical: 6, borderRadius: radius.md, borderWidth: 1, borderColor: colors.borderActive },
  priceText: { color: colors.ice, fontSize: 14, fontWeight: "900" },
  whyRow: { flexDirection: "row", gap: 6, alignItems: "flex-start", marginTop: spacing.sm, paddingTop: spacing.sm, borderTopWidth: 1, borderTopColor: colors.borderSubtle },
  whyText: { color: colors.textSecondary, flex: 1, fontSize: 12, lineHeight: 16 },
  hairGrid: { flexDirection: "row", flexWrap: "wrap", gap: spacing.md, marginBottom: spacing.lg },
  hairCard: { width: "47%", backgroundColor: colors.surface1, borderRadius: radius.lg, padding: spacing.lg, borderWidth: 1, borderColor: colors.borderSubtle, gap: spacing.sm, minHeight: 100 },
  hairName: { color: "#fff", fontWeight: "800", fontSize: 14 },
  hairAction: { color: colors.ice, fontSize: 10, fontWeight: "800", letterSpacing: 1.5 },
  previewCard: { backgroundColor: colors.surface1, borderRadius: radius.xl, overflow: "hidden", borderWidth: 1, borderColor: colors.borderActive, marginBottom: spacing.lg },
  previewLabel: { color: colors.ice, padding: spacing.md, letterSpacing: 2, fontWeight: "800", fontSize: 11 },
  previewImg: { width: "100%", aspectRatio: 1 },
  styleCard: { backgroundColor: colors.surface1, borderRadius: radius.lg, padding: spacing.lg, borderWidth: 1, borderColor: colors.borderSubtle, marginBottom: spacing.lg },
  styleSubLabel: { color: colors.textTertiary, fontSize: 9, letterSpacing: 2, fontWeight: "800", marginBottom: spacing.sm },
  colorRow: { flexDirection: "row", flexWrap: "wrap", gap: 6 },
  colorChip: { paddingHorizontal: 10, paddingVertical: 6, borderRadius: radius.pill, backgroundColor: colors.surface2, borderWidth: 1, borderColor: colors.borderSubtle },
  colorChipAvoid: { borderColor: "rgba(255,59,48,0.4)" },
  colorChipText: { color: "#fff", fontSize: 12, fontWeight: "700" },
  jewelryCard: { flexDirection: "row", gap: spacing.md, backgroundColor: colors.surface1, borderRadius: radius.lg, padding: spacing.lg, borderWidth: 1, borderColor: "rgba(212,175,55,0.4)", marginBottom: spacing.lg, alignItems: "center" },
  jewelryIconWrap: { width: 48, height: 48, borderRadius: 24, backgroundColor: "rgba(212,175,55,0.15)", alignItems: "center", justifyContent: "center" },
  jewelryLabel: { color: colors.gold, fontSize: 9, letterSpacing: 2, fontWeight: "900" },
  jewelryText: { color: "#fff", fontSize: 14, fontWeight: "600", lineHeight: 20, marginTop: 4 },
  accCard: { flexDirection: "row", gap: spacing.md, alignItems: "flex-start", backgroundColor: colors.surface1, borderRadius: radius.md, padding: spacing.md, borderWidth: 1, borderColor: colors.borderSubtle, marginBottom: spacing.sm },
  accBadge: { width: 28, height: 28, borderRadius: 14, backgroundColor: colors.gold, alignItems: "center", justifyContent: "center" },
  accBadgeText: { color: "#000", fontWeight: "900", fontSize: 13 },
  accText: { color: "#fff", flex: 1, fontSize: 14, lineHeight: 20 },
});
