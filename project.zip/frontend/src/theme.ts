export const colors = {
  bg: "#050505",
  surface1: "#0F0F11",
  surface2: "#1A1A1D",
  surface3: "#252528",
  ice: "#00E5FF",
  iceGlow: "rgba(0, 229, 255, 0.35)",
  ascend: "#00FF9D",
  descend: "#FF3B30",
  gold: "#D4AF37",
  goldGlow: "rgba(212, 175, 55, 0.25)",
  textPrimary: "#FFFFFF",
  textSecondary: "#A1A1AA",
  textTertiary: "#52525B",
  borderSubtle: "rgba(255, 255, 255, 0.08)",
  borderActive: "rgba(0, 229, 255, 0.35)",
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  xxl: 32,
  xxxl: 48,
};

export const radius = {
  sm: 6,
  md: 10,
  lg: 14,
  xl: 20,
  pill: 999,
};

export const fonts = {
  // Use system display fonts to avoid font loading issues
  display: undefined as undefined,
  body: undefined as undefined,
};
