"""Moglabs backend API test suite — covers auth, scans, progress, payments, premium gating."""
import time
import uuid
import pytest
import requests
from pymongo import MongoClient
import os

EXPECTED_METRIC_KEYS = {
    "skin_texture", "facial_muscles", "facial_hair", "jaw_line",
    "nose_structure", "hair_texture", "hair_style", "cheek_bones",
    "neck_muscles", "eye_shape", "overall_potential",
}


# ----------------------------- Health -----------------------------
class TestHealth:
    def test_root(self, api_client, base_url):
        r = api_client.get(f"{base_url}/api/", timeout=15)
        assert r.status_code == 200
        body = r.json()
        assert body.get("status") == "ok"
        assert body.get("app") == "Moglabs"


# ----------------------------- Auth -----------------------------
class TestAuth:
    def test_register_returns_token_and_user(self, primary_user):
        assert primary_user["token"]
        u = primary_user["user"]
        assert u["email"] == primary_user["email"]
        assert u["is_premium"] is False
        assert "id" in u and u["id"]
        assert "created_at" in u

    def test_register_duplicate_email_rejected(self, api_client, base_url, primary_user):
        r = api_client.post(
            f"{base_url}/api/auth/register",
            json={"email": primary_user["email"], "password": "anotherPass123", "name": "dup"},
            timeout=20,
        )
        assert r.status_code == 400

    def test_login_success(self, api_client, base_url, primary_user):
        r = api_client.post(
            f"{base_url}/api/auth/login",
            json={"email": primary_user["email"], "password": primary_user["password"]},
            timeout=20,
        )
        assert r.status_code == 200
        body = r.json()
        assert body["access_token"]
        assert body["user"]["email"] == primary_user["email"]

    def test_login_wrong_password_401(self, api_client, base_url, primary_user):
        r = api_client.post(
            f"{base_url}/api/auth/login",
            json={"email": primary_user["email"], "password": "wrong_password!!"},
            timeout=20,
        )
        assert r.status_code == 401

    def test_me_with_token(self, api_client, base_url, primary_user, auth_header):
        r = api_client.get(f"{base_url}/api/auth/me", headers=auth_header, timeout=20)
        assert r.status_code == 200
        assert r.json()["email"] == primary_user["email"]

    def test_me_without_token_401(self, api_client, base_url):
        r = api_client.get(f"{base_url}/api/auth/me", timeout=20)
        assert r.status_code == 401


# ----------------------------- Scans -----------------------------
class TestScans:
    """Create a scan using Gemini vision, then verify list/get and scoping."""

    def test_create_scan_returns_full_structure(self, api_client, base_url, auth_header, face_image_b64, primary_user):
        r = api_client.post(
            f"{base_url}/api/scans",
            headers=auth_header,
            json={"image_b64": face_image_b64},
            timeout=120,
        )
        assert r.status_code == 200, f"scan failed: {r.status_code} {r.text[:300]}"
        data = r.json()
        # Persist for later tests
        pytest.scan_id = data["id"]
        pytest.scan_owner = primary_user["user"]["id"]

        # required top-level fields
        for k in [
            "id", "user_id", "overall_score", "symmetry_score", "face_shape",
            "hairline_type", "metrics", "skin_recommendations", "hair_recommendations",
            "hairstyle_suggestions", "summary", "image_b64", "created_at",
        ]:
            assert k in data, f"missing field: {k}"

        assert data["user_id"] == primary_user["user"]["id"]
        assert isinstance(data["overall_score"], (int, float))
        assert 0 <= data["overall_score"] <= 10
        assert 0 <= data["symmetry_score"] <= 10
        assert data["face_shape"]
        assert data["hairline_type"]

        # 11 metrics with the exact required keys
        assert isinstance(data["metrics"], list)
        assert len(data["metrics"]) == 11, f"expected 11 metrics, got {len(data['metrics'])}"
        keys = {m["key"] for m in data["metrics"]}
        missing = EXPECTED_METRIC_KEYS - keys
        assert not missing, f"missing metric keys: {missing}"
        for m in data["metrics"]:
            assert "label" in m and m["label"]
            assert "score" in m and 0 <= float(m["score"]) <= 10
            assert "note" in m

        # Recommendations lists non-empty (3-5)
        for fld in ("skin_recommendations", "hair_recommendations", "hairstyle_suggestions"):
            assert isinstance(data[fld], list) and len(data[fld]) >= 1, f"{fld} empty"
        assert isinstance(data["summary"], str) and data["summary"]

    def test_create_scan_invalid_image(self, api_client, base_url, auth_header):
        r = api_client.post(
            f"{base_url}/api/scans",
            headers=auth_header,
            json={"image_b64": "tiny"},
            timeout=30,
        )
        assert r.status_code == 400

    def test_create_scan_requires_auth(self, api_client, base_url, face_image_b64):
        r = api_client.post(f"{base_url}/api/scans", json={"image_b64": face_image_b64}, timeout=30)
        assert r.status_code == 401

    def test_list_scans_returns_own_only(self, api_client, base_url, auth_header, primary_user):
        r = api_client.get(f"{base_url}/api/scans", headers=auth_header, timeout=30)
        assert r.status_code == 200
        scans = r.json()
        assert isinstance(scans, list) and len(scans) >= 1
        for s in scans:
            assert s["user_id"] == primary_user["user"]["id"]

    def test_get_scan_by_id(self, api_client, base_url, auth_header):
        scan_id = getattr(pytest, "scan_id", None)
        if not scan_id:
            pytest.skip("scan_id not set from previous test")
        r = api_client.get(f"{base_url}/api/scans/{scan_id}", headers=auth_header, timeout=30)
        assert r.status_code == 200
        assert r.json()["id"] == scan_id

    def test_get_other_users_scan_returns_404(self, api_client, base_url, secondary_user):
        """Auth-scoping: secondary user must not be able to read primary user's scan."""
        scan_id = getattr(pytest, "scan_id", None)
        if not scan_id:
            pytest.skip("scan_id not set")
        h = {"Authorization": f"Bearer {secondary_user['token']}"}
        r = api_client.get(f"{base_url}/api/scans/{scan_id}", headers=h, timeout=30)
        assert r.status_code == 404

    def test_list_scans_other_user_empty(self, api_client, base_url, secondary_user):
        h = {"Authorization": f"Bearer {secondary_user['token']}"}
        r = api_client.get(f"{base_url}/api/scans", headers=h, timeout=30)
        assert r.status_code == 200
        assert r.json() == []


# ----------------------------- Progress -----------------------------
class TestProgress:
    def test_progress_insufficient_with_one_scan(self, api_client, base_url, auth_header):
        r = api_client.get(f"{base_url}/api/progress", headers=auth_header, timeout=20)
        assert r.status_code == 200
        body = r.json()
        # may be insufficient (1 scan) or already directional if >=2 — assert structure
        assert body["direction"] in {"insufficient", "ascending", "descending", "steady"}
        assert isinstance(body["points"], list)
        if len(body["points"]) < 2:
            assert body["direction"] == "insufficient"
            assert body["delta"] == 0.0

    def test_progress_directional_after_second_scan(self, api_client, base_url, auth_header, face_image_b64):
        # Create a second scan to trigger direction calculation
        r = api_client.post(
            f"{base_url}/api/scans",
            headers=auth_header,
            json={"image_b64": face_image_b64},
            timeout=120,
        )
        assert r.status_code == 200, f"2nd scan failed: {r.text[:200]}"

        r2 = api_client.get(f"{base_url}/api/progress", headers=auth_header, timeout=20)
        assert r2.status_code == 200
        body = r2.json()
        assert body["direction"] in {"ascending", "descending", "steady"}
        assert len(body["points"]) >= 2


# ----------------------------- Payments -----------------------------
class TestPayments:
    def test_create_checkout_session(self, api_client, base_url, secondary_user):
        """Use secondary user (still non-premium) to create a checkout session."""
        h = {"Authorization": f"Bearer {secondary_user['token']}"}
        r = api_client.post(f"{base_url}/api/payments/create-checkout-session", headers=h, timeout=30)
        assert r.status_code == 200, f"checkout failed: {r.text[:300]}"
        body = r.json()
        assert body["checkout_url"].startswith("https://")
        assert body["session_id"].startswith("cs_")
        pytest.checkout_session_id = body["session_id"]
        pytest.checkout_user_token = secondary_user["token"]

    def test_payment_status_unpaid(self, api_client, base_url):
        sid = getattr(pytest, "checkout_session_id", None)
        token = getattr(pytest, "checkout_user_token", None)
        if not sid:
            pytest.skip("no checkout session")
        h = {"Authorization": f"Bearer {token}"}
        r = api_client.get(f"{base_url}/api/payments/status/{sid}", headers=h, timeout=30)
        assert r.status_code == 200
        body = r.json()
        assert "paid" in body
        # Unpaid is expected for a fresh test session
        assert body["paid"] is False

    def test_already_premium_rejected(self, api_client, base_url, primary_user):
        """Flip is_premium=true in mongo and verify checkout returns 400."""
        mongo_url = os.environ["MONGO_URL"]
        db_name = os.environ["DB_NAME"]
        mc = MongoClient(mongo_url)
        try:
            res = mc[db_name]["users"].update_one(
                {"id": primary_user["user"]["id"]},
                {"$set": {"is_premium": True}},
            )
            assert res.modified_count == 1
            h = {"Authorization": f"Bearer {primary_user['token']}"}
            r = api_client.post(f"{base_url}/api/payments/create-checkout-session", headers=h, timeout=30)
            assert r.status_code == 400
        finally:
            mc.close()


# ----------------------------- Premium: hairstyle preview -----------------------------
class TestHairstylePreview:
    def test_non_premium_blocked(self, api_client, base_url, secondary_user):
        h = {"Authorization": f"Bearer {secondary_user['token']}"}
        r = api_client.post(
            f"{base_url}/api/hairstyle/preview",
            headers=h,
            json={"scan_id": "anything", "hairstyle": "Textured Crop"},
            timeout=30,
        )
        assert r.status_code == 403

    def test_premium_generates_image(self, api_client, base_url, primary_user):
        """Primary user was flipped to premium in TestPayments.test_already_premium_rejected."""
        scan_id = getattr(pytest, "scan_id", None)
        if not scan_id:
            pytest.skip("no scan_id")
        h = {"Authorization": f"Bearer {primary_user['token']}"}
        r = api_client.post(
            f"{base_url}/api/hairstyle/preview",
            headers=h,
            json={"scan_id": scan_id, "hairstyle": "Textured Crop"},
            timeout=120,
        )
        assert r.status_code == 200, f"preview failed: {r.status_code} {r.text[:300]}"
        body = r.json()
        assert body["hairstyle"] == "Textured Crop"
        assert isinstance(body["image_b64"], str) and len(body["image_b64"]) > 500

    def test_premium_scan_not_found(self, api_client, base_url, primary_user):
        h = {"Authorization": f"Bearer {primary_user['token']}"}
        r = api_client.post(
            f"{base_url}/api/hairstyle/preview",
            headers=h,
            json={"scan_id": "non-existent-scan-id", "hairstyle": "Buzz Cut"},
            timeout=30,
        )
        assert r.status_code == 404


# ----------------------------- Cleanup -----------------------------
@pytest.fixture(scope="session", autouse=True)
def _cleanup_test_users(request):
    """Delete TEST_ prefixed users and their scans/payments at session end."""
    yield
    try:
        mc = MongoClient(os.environ["MONGO_URL"])
        db = mc[os.environ["DB_NAME"]]
        # Find TEST_ users
        users = list(db["users"].find({"email": {"$regex": "^test_", "$options": "i"}}, {"id": 1, "_id": 0}))
        ids = [u["id"] for u in users]
        if ids:
            db["scans"].delete_many({"user_id": {"$in": ids}})
            db["payments"].delete_many({"user_id": {"$in": ids}})
            db["users"].delete_many({"id": {"$in": ids}})
        mc.close()
    except Exception as e:
        print(f"cleanup warning: {e}")
