"""Shared fixtures for Moglabs backend tests."""
import os
import base64
import uuid
import pytest
import requests
from pathlib import Path
from dotenv import load_dotenv

# Load backend .env so MONGO_URL/DB_NAME are available for direct mongo operations.
load_dotenv(Path(__file__).resolve().parents[1] / ".env")

BASE_URL = os.environ["EXPO_BACKEND_URL"].rstrip("/") if os.environ.get("EXPO_BACKEND_URL") else "https://moglabs-beauty.preview.emergentagent.com"


@pytest.fixture(scope="session")
def base_url() -> str:
    return BASE_URL


@pytest.fixture(scope="session")
def api_client() -> requests.Session:
    s = requests.Session()
    s.headers.update({"Content-Type": "application/json"})
    return s


@pytest.fixture(scope="session")
def face_image_b64() -> str:
    """Real JPEG selfie of a face for Gemini vision tests."""
    p = Path("/tmp/test_face.jpg")
    return base64.b64encode(p.read_bytes()).decode("ascii")


def _register(api_client, base_url, email=None, password="TEST_pass_1234", name="TEST User"):
    email = email or f"test_{uuid.uuid4().hex[:10]}@moglabs.dev"
    r = api_client.post(
        f"{base_url}/api/auth/register",
        json={"email": email, "password": password, "name": name},
        timeout=30,
    )
    return email, password, r


@pytest.fixture(scope="session")
def primary_user(api_client, base_url):
    """Register a fresh primary user for the test session."""
    email, password, r = _register(api_client, base_url)
    assert r.status_code == 200, f"register failed: {r.status_code} {r.text}"
    data = r.json()
    return {
        "email": email,
        "password": password,
        "token": data["access_token"],
        "user": data["user"],
    }


@pytest.fixture(scope="session")
def secondary_user(api_client, base_url):
    """A second user for auth-scoping tests."""
    email, password, r = _register(api_client, base_url)
    assert r.status_code == 200
    data = r.json()
    return {
        "email": email,
        "password": password,
        "token": data["access_token"],
        "user": data["user"],
    }


@pytest.fixture
def auth_header(primary_user):
    return {"Authorization": f"Bearer {primary_user['token']}"}
