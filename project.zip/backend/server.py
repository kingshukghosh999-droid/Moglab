"""Moglabs backend — facial symmetry analysis, Stripe Ascend subscription, JWT auth."""
import os
import json
import uuid
import base64
import logging
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import List, Optional, Annotated

from fastapi import FastAPI, APIRouter, HTTPException, Depends, status, Request
from fastapi.security import OAuth2PasswordBearer
from starlette.middleware.cors import CORSMiddleware
from dotenv import load_dotenv
from motor.motor_asyncio import AsyncIOMotorClient
from pydantic import BaseModel, EmailStr, Field
from passlib.context import CryptContext
from jose import jwt, JWTError
from emergentintegrations.llm.chat import LlmChat, UserMessage, ImageContent
from emergentintegrations.payments.stripe.checkout import (
    StripeCheckout,
    CheckoutSessionRequest,
)

# ---------------------------------------------------------------------------
# Setup
# ---------------------------------------------------------------------------
ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / ".env")

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
logger = logging.getLogger("moglabs")

MONGO_URL = os.environ["MONGO_URL"]
DB_NAME = os.environ["DB_NAME"]
EMERGENT_LLM_KEY = os.environ["EMERGENT_LLM_KEY"]
JWT_SECRET = os.environ["JWT_SECRET"]
JWT_ALGORITHM = os.environ.get("JWT_ALGORITHM", "HS256")
JWT_EXPIRES_MINUTES = int(os.environ.get("JWT_EXPIRES_MINUTES", "10080"))
STRIPE_API_KEY = os.environ.get("STRIPE_API_KEY", "")
ASCEND_PRICE_USD = float(os.environ.get("ASCEND_PRICE_USD", "1"))
FRONTEND_BASE_URL = os.environ.get("FRONTEND_BASE_URL", "")

stripe_checkout = StripeCheckout(api_key=STRIPE_API_KEY)

client = AsyncIOMotorClient(MONGO_URL)
db = client[DB_NAME]
users_col = db["users"]
scans_col = db["scans"]
payments_col = db["payments"]

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/login", auto_error=False)

app = FastAPI(title="Moglabs API")
api = APIRouter(prefix="/api")


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------
class UserRegister(BaseModel):
    email: EmailStr
    password: str = Field(min_length=6, max_length=128)
    name: Optional[str] = None
    gender: Optional[str] = "neutral"


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class UserPublic(BaseModel):
    id: str
    email: EmailStr
    name: Optional[str] = None
    gender: str = "neutral"
    is_premium: bool = False
    created_at: datetime


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserPublic


class MetricScore(BaseModel):
    key: str
    label: str
    score: float
    note: str


class Product(BaseModel):
    name: str
    brand: str
    price_inr: str
    why: str


class StyleRecommendations(BaseModel):
    outfit_colors: List[str] = []
    colors_to_avoid: List[str] = []
    jewelry: str = ""
    accessories: List[str] = []


class ScanResult(BaseModel):
    id: str
    user_id: str
    overall_score: float
    symmetry_score: float
    tier: str = "mtn"
    tier_label: str = "MTN"
    tier_explanation: str = ""
    face_shape: str
    hairline_type: str
    skin_undertone: str = "neutral"
    metrics: List[MetricScore]
    skin_recommendations: List[str] = []
    hair_recommendations: List[str] = []
    skin_products: List[Product] = []
    hair_products: List[Product] = []
    hairstyle_suggestions: List[str] = []
    looksmax_methods: List[str] = []
    style_recommendations: StyleRecommendations = StyleRecommendations()
    celebrity_lookalikes: List[dict] = []
    summary: str
    image_b64: str
    created_at: datetime


class ScanCreate(BaseModel):
    image_b64: str  # base64 image (no data URI prefix)


class HairstylePreviewRequest(BaseModel):
    scan_id: str
    hairstyle: str


class HairstylePreviewResult(BaseModel):
    hairstyle: str
    image_b64: str


class ChatMessageIn(BaseModel):
    message: str = Field(min_length=1, max_length=2000)


class ChatMessage(BaseModel):
    id: str
    role: str  # "user" | "assistant"
    content: str
    created_at: datetime


class ChatResponse(BaseModel):
    user_message: ChatMessage
    assistant_message: ChatMessage


class CheckoutSessionResponse(BaseModel):
    checkout_url: str
    session_id: str


# ---------------------------------------------------------------------------
# Auth helpers
# ---------------------------------------------------------------------------
def hash_password(pw: str) -> str:
    return pwd_context.hash(pw)


def verify_password(pw: str, hashed: str) -> bool:
    return pwd_context.verify(pw, hashed)


def create_access_token(user_id: str) -> str:
    exp = datetime.now(timezone.utc) + timedelta(minutes=JWT_EXPIRES_MINUTES)
    payload = {"sub": user_id, "exp": exp}
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)


def serialize_user(doc: dict) -> UserPublic:
    return UserPublic(
        id=doc["id"],
        email=doc["email"],
        name=doc.get("name"),
        gender=doc.get("gender") or "neutral",
        is_premium=bool(doc.get("is_premium", False)),
        created_at=doc["created_at"],
    )


async def get_current_user(token: Annotated[Optional[str], Depends(oauth2_scheme)]) -> dict:
    if not token:
        raise HTTPException(status_code=401, detail="Missing token")
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        user_id = payload.get("sub")
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")
    if not user_id:
        raise HTTPException(status_code=401, detail="Invalid token payload")
    user = await users_col.find_one({"id": user_id}, {"_id": 0})
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    return user


async def require_premium(user: Annotated[dict, Depends(get_current_user)]) -> dict:
    # Premium gating disabled — all features are free for everyone.
    return user


# ---------------------------------------------------------------------------
# Auth routes
# ---------------------------------------------------------------------------
@api.post("/auth/register", response_model=TokenResponse)
async def register(payload: UserRegister):
    existing = await users_col.find_one({"email": payload.email.lower()})
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")
    user_doc = {
        "id": str(uuid.uuid4()),
        "email": payload.email.lower(),
        "name": payload.name or payload.email.split("@")[0],
        "gender": (payload.gender or "neutral").lower(),
        "hashed_password": hash_password(payload.password),
        "is_premium": True,  # Premium is free for everyone right now.
        "created_at": datetime.now(timezone.utc),
    }
    await users_col.insert_one(user_doc)
    token = create_access_token(user_doc["id"])
    return TokenResponse(access_token=token, user=serialize_user(user_doc))


@api.post("/auth/login", response_model=TokenResponse)
async def login(payload: UserLogin):
    user = await users_col.find_one({"email": payload.email.lower()}, {"_id": 0})
    if not user or not verify_password(payload.password, user["hashed_password"]):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    token = create_access_token(user["id"])
    return TokenResponse(access_token=token, user=serialize_user(user))


@api.get("/auth/me", response_model=UserPublic)
async def me(user: Annotated[dict, Depends(get_current_user)]):
    # Lazily upgrade legacy users — premium is free for everyone right now.
    if not user.get("is_premium"):
        await users_col.update_one({"id": user["id"]}, {"$set": {"is_premium": True}})
        user["is_premium"] = True
    return serialize_user(user)


# ---------------------------------------------------------------------------
# Facial analysis via Gemini 3 Flash vision
# ---------------------------------------------------------------------------
ANALYSIS_SYSTEM_PROMPT = """You are MogLabs' chief aesthetic scientist — a brutally honest but constructive
analyzer of facial aesthetics, symmetry, and looksmaxxing potential for an INDIAN audience.

You score 11 attributes out of 10, assign a tier ranking, recommend India-available products
with INR pricing, suggest outfit colors/jewelry, and prescribe specific looksmax methods.

You MUST always return valid minified JSON only — no markdown, no code fences, no commentary.

Scoring rubric (0.0 to 10.0, one decimal):
- 9-10: elite / model tier
- 7-8.9: strong / above average
- 5-6.9: average
- 3-4.9: needs work
- 0-2.9: significant improvement potential

Tier ranking based on overall_score:
- "sub3" / "Sub-3" : overall < 2.5  (significant work needed across multiple dimensions)
- "sub5" / "Sub-5" : 2.5 to 3.4     (multiple major weaknesses)
- "ltn"  / "LTN"   : 3.5 to 4.9     (Low-Tier Normie — below average)
- "mtn"  / "MTN"   : 5.0 to 6.4     (Mid-Tier Normie — average)
- "htn"  / "HTN"   : 6.5 to 7.4     (High-Tier Normie — above average)
- "chad-lite" / "Chad-Lite" : 7.5 to 8.7  (very handsome, strong features)
- "chad" / "Chad"  : 8.8+            (elite / model tier)

India-specific product brands you may reference (use ONLY real, currently-sold brands):
- Skincare: Minimalist (Be Minimalist), The Derma Co, Plum, Foxtale, Dot & Key, Re'equil, Pilgrim,
  Mamaearth, Cetaphil India, La Shield, Bombay Shaving Co, Beardo, Aqualogica, Suganda
- Haircare: WOW Skin Science, Mamaearth, Minimalist, Bare Anatomy, Arata, Pilgrim, BBlunt,
  The Man Company, Beardo, Ustraa, Dr Batra's

Price ranges in INR (₹):
- Budget: ₹200–500
- Mid: ₹500–1500
- Premium: ₹1500–3500
- Luxury: ₹3500+

Voice: precise, masculine, motivating. No fluff. Use actual visible features only.

Required JSON schema:
{
  "overall_score": float,
  "symmetry_score": float,
  "tier": "sub3|sub5|ltn|mtn|htn|chad-lite|chad",
  "tier_label": "Sub-3 | Sub-5 | LTN | MTN | HTN | Chad-Lite | Chad",
  "tier_explanation": "<=25 words why they sit in this tier",
  "face_shape": "oval|round|square|oblong|heart|diamond|triangle",
  "hairline_type": "straight|widow's peak|receding|mature|juvenile|m-shaped",
  "skin_undertone": "warm|cool|neutral",
  "metrics": [
    {"key":"skin_texture","label":"Skin Texture","score":float,"note":"<=18 words"},
    {"key":"facial_muscles","label":"Facial Muscles","score":float,"note":"<=18 words"},
    {"key":"facial_hair","label":"Facial Hair","score":float,"note":"<=18 words"},
    {"key":"jaw_line","label":"Jaw Line","score":float,"note":"<=18 words"},
    {"key":"nose_structure","label":"Nose Structure","score":float,"note":"<=18 words"},
    {"key":"hair_texture","label":"Hair Texture","score":float,"note":"<=18 words"},
    {"key":"hair_style","label":"Hair Style","score":float,"note":"<=18 words"},
    {"key":"cheek_bones","label":"Cheek Bones","score":float,"note":"<=18 words"},
    {"key":"neck_muscles","label":"Neck Muscles","score":float,"note":"<=18 words"},
    {"key":"eye_shape","label":"Eye Shape","score":float,"note":"<=18 words"},
    {"key":"overall_potential","label":"Overall Potential","score":float,"note":"<=18 words"}
  ],
  "skin_recommendations": ["3 short routine tips, each <=15 words"],
  "hair_recommendations": ["3 short routine tips, each <=15 words"],
  "skin_products": [
    {"name":"e.g. 10% Niacinamide Face Serum","brand":"Minimalist","price_inr":"₹599","why":"<=14 words tied to THIS face's weak point"}
  ],
  "hair_products": [
    {"name":"e.g. Onion Hair Oil","brand":"WOW Skin Science","price_inr":"₹399","why":"<=14 words tied to this person's hair issue"}
  ],
  "hairstyle_suggestions": ["3-5 specific hairstyle names matching face shape + hairline"],
  "looksmax_methods": [
    "5-7 specific, actionable methods tailored to THIS person's weakest metrics. Each <=22 words. Examples: 'Mew daily 30min — tongue on roof, lips sealed, to define jaw long-term.', 'Switch to silk pillowcase to cut sleep creases on cheeks.', 'Add weighted chin tucks 3x/week to build neck width.'"
  ],
  "celebrity_lookalikes": [
    {"name":"Celebrity full name","industry":"Bollywood|Hollywood|South Indian|Korean|Other","similarity":float (0-100),"shared_features":"<=14 words on what features match this user"}
  ],
  "style_recommendations": {
    "outfit_colors": ["5 specific color names that flatter the user's skin undertone, e.g. 'Deep olive', 'Burnt orange'"],
    "colors_to_avoid": ["2-3 specific colors that wash this undertone out"],
    "jewelry": "gold | silver | both | rose-gold — with <=20 words why",
    "accessories": ["3 specific accessory tips: e.g. 'Square wayfarer sunglasses to soften round face', 'Matte black analog watch'"]
  },
  "summary": "<=45 words motivational verdict referring to their strongest feature and one priority move."
}

Provide 4-5 items each in skin_products and hair_products, mixing budget tiers.
Provide 3-4 celebrity_lookalikes — at least 2 from Bollywood/South Indian cinema if the user appears Indian.
Suggestions should be plausible feature-based comparisons. Similarity is a self-rated 0-100 number; don't exaggerate.
Return ONLY the JSON object."""


async def analyze_selfie(image_b64: str, session_id: str, user_gender: str = "neutral") -> dict:
    """Run Gemini 3 Flash vision and return structured analysis dict."""
    gender_note = ""
    if user_gender == "male":
        gender_note = "\n\nUSER IS MALE. Bias celebrity_lookalikes toward MALE celebrities (Bollywood: Hrithik Roshan, Vicky Kaushal, Ranveer Singh, Siddharth Malhotra, Shahid Kapoor, Kartik Aaryan, Ayushmann Khurrana, Vijay Deverakonda, Allu Arjun; Hollywood: Henry Cavill, Chris Hemsworth, Timothée Chalamet, Robert Pattinson, Jake Gyllenhaal)."
    elif user_gender == "female":
        gender_note = "\n\nUSER IS FEMALE. Bias celebrity_lookalikes toward FEMALE celebrities (Bollywood: Deepika Padukone, Alia Bhatt, Kiara Advani, Janhvi Kapoor, Rashmika Mandanna, Kriti Sanon, Sara Ali Khan, Disha Patani, Sai Pallavi; Hollywood: Zendaya, Margot Robbie, Gal Gadot, Anya Taylor-Joy, Sydney Sweeney)."

    chat = LlmChat(
        api_key=EMERGENT_LLM_KEY,
        session_id=session_id,
        system_message=ANALYSIS_SYSTEM_PROMPT + gender_note,
    ).with_model("gemini", "gemini-3-flash-preview")

    msg = UserMessage(
        text="Analyze this selfie and return the JSON object exactly as specified.",
        file_contents=[ImageContent(image_base64=image_b64)],
    )
    raw = await chat.send_message(msg)
    text = raw.strip() if isinstance(raw, str) else str(raw).strip()
    # Strip code fences if model wraps them
    if text.startswith("```"):
        text = text.strip("`")
        if text.lower().startswith("json"):
            text = text[4:].lstrip()
    # Find the first { ... last } to be safe
    first = text.find("{")
    last = text.rfind("}")
    if first != -1 and last != -1:
        text = text[first : last + 1]
    try:
        data = json.loads(text)
    except json.JSONDecodeError as e:
        logger.error("Analysis JSON parse failed: %s | raw: %s", e, text[:300])
        raise HTTPException(status_code=502, detail="Analysis model returned invalid JSON")
    return data


@api.post("/scans", response_model=ScanResult)
async def create_scan(
    body: ScanCreate,
    user: Annotated[dict, Depends(get_current_user)],
):
    if not body.image_b64 or len(body.image_b64) < 100:
        raise HTTPException(status_code=400, detail="Invalid image")
    # Normalize: strip data URI prefix
    img = body.image_b64
    if img.startswith("data:"):
        img = img.split(",", 1)[1] if "," in img else img

    session_id = f"scan-{user['id']}-{uuid.uuid4().hex[:8]}"
    try:
        data = await analyze_selfie(img, session_id, user.get("gender", "neutral"))
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("Selfie analysis failed")
        raise HTTPException(status_code=502, detail=f"Analysis failed: {e}")

    scan_doc = {
        "id": str(uuid.uuid4()),
        "user_id": user["id"],
        "overall_score": float(data.get("overall_score", 0)),
        "symmetry_score": float(data.get("symmetry_score", 0)),
        "tier": str(data.get("tier", "mtn")).lower(),
        "tier_label": str(data.get("tier_label", "MTN")),
        "tier_explanation": str(data.get("tier_explanation", "")),
        "face_shape": str(data.get("face_shape", "oval")),
        "hairline_type": str(data.get("hairline_type", "straight")),
        "skin_undertone": str(data.get("skin_undertone", "neutral")),
        "metrics": data.get("metrics", []),
        "skin_recommendations": data.get("skin_recommendations", []),
        "hair_recommendations": data.get("hair_recommendations", []),
        "skin_products": data.get("skin_products", []),
        "hair_products": data.get("hair_products", []),
        "hairstyle_suggestions": data.get("hairstyle_suggestions", []),
        "looksmax_methods": data.get("looksmax_methods", []),
        "style_recommendations": data.get("style_recommendations", {}),
        "celebrity_lookalikes": data.get("celebrity_lookalikes", []),
        "summary": str(data.get("summary", "")),
        "image_b64": img,
        "created_at": datetime.now(timezone.utc),
    }
    await scans_col.insert_one(scan_doc.copy())
    scan_doc.pop("_id", None)
    return ScanResult(**scan_doc)


@api.get("/scans", response_model=List[ScanResult])
async def list_scans(user: Annotated[dict, Depends(get_current_user)]):
    cursor = scans_col.find({"user_id": user["id"]}, {"_id": 0}).sort("created_at", -1).limit(100)
    docs = await cursor.to_list(length=100)
    return [ScanResult(**d) for d in docs]


@api.get("/scans/{scan_id}", response_model=ScanResult)
async def get_scan(scan_id: str, user: Annotated[dict, Depends(get_current_user)]):
    doc = await scans_col.find_one({"id": scan_id, "user_id": user["id"]}, {"_id": 0})
    if not doc:
        raise HTTPException(status_code=404, detail="Scan not found")
    return ScanResult(**doc)


@api.delete("/scans/{scan_id}")
async def delete_scan(scan_id: str, user: Annotated[dict, Depends(get_current_user)]):
    res = await scans_col.delete_one({"id": scan_id, "user_id": user["id"]})
    if res.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Scan not found")
    return {"deleted": True}


class ProgressPoint(BaseModel):


@api.post("/scans/{scan_id}/celebrities/reroll", response_model=ScanResult)
async def reroll_celebrities(scan_id: str, user: Annotated[dict, Depends(get_current_user)]):
    scan = await scans_col.find_one({"id": scan_id, "user_id": user["id"]}, {"_id": 0})
    if not scan:
        raise HTTPException(status_code=404, detail="Scan not found")

    current = scan.get("celebrity_lookalikes", []) or []
    exclude_names = [c.get("name") for c in current if c.get("name")]
    user_gender = user.get("gender", "neutral")
    gender_clause = ""
    if user_gender == "male":
        gender_clause = "Use only MALE celebrities (Bollywood + Hollywood + South Indian)."
    elif user_gender == "female":
        gender_clause = "Use only FEMALE celebrities (Bollywood + Hollywood + South Indian)."
    exclude_clause = (
        f" Do NOT include these (already shown): {', '.join(exclude_names)}." if exclude_names else ""
    )

    system = (
        "You are a face-matching expert. Given a selfie, return ONLY a JSON array of 3-4 plausible "
        "celebrity lookalikes for this person. " + gender_clause + exclude_clause + " "
        "Schema: [{\"name\":\"Full name\",\"industry\":\"Bollywood|Hollywood|South Indian|Korean\","
        "\"similarity\":float,\"shared_features\":\"<=14 words\"}]. Return ONLY the JSON array."
    )

    session_id = f"reroll-{user['id']}-{uuid.uuid4().hex[:8]}"
    chat = LlmChat(
        api_key=EMERGENT_LLM_KEY,
        session_id=session_id,
        system_message=system,
    ).with_model("gemini", "gemini-3-flash-preview")

    msg = UserMessage(
        text="Match this person to celebrity lookalikes. Return only the JSON array.",
        file_contents=[ImageContent(image_base64=scan["image_b64"])],
    )
    try:
        raw = await chat.send_message(msg)
        text = raw if isinstance(raw, str) else str(raw)
        text = text.strip()
        if text.startswith("```"):
            text = text.strip("`")
            if text.lower().startswith("json"):
                text = text[4:].lstrip()
        first = text.find("[")
        last = text.rfind("]")
        if first != -1 and last != -1:
            text = text[first : last + 1]
        new_celebs = json.loads(text)
        if not isinstance(new_celebs, list):
            raise ValueError("not a list")
    except Exception as e:
        logger.exception("Celebrity reroll failed")
        raise HTTPException(status_code=502, detail=f"Reroll failed: {e}")

    await scans_col.update_one(
        {"id": scan_id, "user_id": user["id"]},
        {"$set": {"celebrity_lookalikes": new_celebs}},
    )
    scan["celebrity_lookalikes"] = new_celebs
    return ScanResult(**scan)


    scan_id: str
    created_at: datetime
    overall_score: float
    symmetry_score: float


class ProgressResponse(BaseModel):
    direction: str  # "ascending" | "descending" | "steady" | "insufficient"
    delta: float
    points: List[ProgressPoint]


@api.get("/progress", response_model=ProgressResponse)
async def progress(user: Annotated[dict, Depends(get_current_user)]):
    cursor = scans_col.find(
        {"user_id": user["id"]},
        {"_id": 0, "id": 1, "created_at": 1, "overall_score": 1, "symmetry_score": 1},
    ).sort("created_at", 1)
    docs = await cursor.to_list(length=500)
    points = [
        ProgressPoint(
            scan_id=d["id"],
            created_at=d["created_at"],
            overall_score=d["overall_score"],
            symmetry_score=d["symmetry_score"],
        )
        for d in docs
    ]
    if len(points) < 2:
        return ProgressResponse(direction="insufficient", delta=0.0, points=points)
    delta = points[-1].overall_score - points[0].overall_score
    if delta > 0.2:
        direction = "ascending"
    elif delta < -0.2:
        direction = "descending"
    else:
        direction = "steady"
    return ProgressResponse(direction=direction, delta=round(delta, 2), points=points)


# ---------------------------------------------------------------------------
# Premium: Hairstyle preview via Gemini Nano Banana image generation
# ---------------------------------------------------------------------------
@api.post("/hairstyle/preview", response_model=HairstylePreviewResult)
async def hairstyle_preview(
    body: HairstylePreviewRequest,
    user: Annotated[dict, Depends(require_premium)],
):
    scan = await scans_col.find_one({"id": body.scan_id, "user_id": user["id"]}, {"_id": 0})
    if not scan:
        raise HTTPException(status_code=404, detail="Scan not found")
    session_id = f"hair-{user['id']}-{uuid.uuid4().hex[:8]}"
    chat = (
        LlmChat(
            api_key=EMERGENT_LLM_KEY,
            session_id=session_id,
            system_message="You are an elite barber visualizer. Generate a photorealistic preview.",
        )
        .with_model("gemini", "gemini-3.1-flash-image-preview")
        .with_params(modalities=["image", "text"])
    )
    prompt = (
        f"Take the person in this reference selfie and re-render them with the '{body.hairstyle}' hairstyle. "
        "Keep their face, skin tone, jawline, and ethnicity identical. Photorealistic studio lighting, "
        "dark moody background, sharp focus on the new hair. No text overlay."
    )
    msg = UserMessage(
        text=prompt,
        file_contents=[ImageContent(image_base64=scan["image_b64"])],
    )
    try:
        _text, images = await chat.send_message_multimodal_response(msg)
    except Exception as e:
        logger.exception("Hairstyle preview generation failed")
        raise HTTPException(status_code=502, detail=f"Image generation failed: {e}")
    if not images:
        raise HTTPException(status_code=502, detail="No image generated")
    img_data = images[0]["data"]
    return HairstylePreviewResult(hairstyle=body.hairstyle, image_b64=img_data)


# ---------------------------------------------------------------------------
# AI Coach — Claude Sonnet 4.5 conversational chat with scan context
# ---------------------------------------------------------------------------
COACH_SYSTEM_PROMPT = """You are 'Mog', the in-house AI coach for Moglabs — a no-nonsense, premium
masculine-coded looksmaxxing and self-improvement coach FOR AN INDIAN USER BASE.

Your job is to answer the user's questions about: skincare, haircare, hairstyles, jawline training,
fitness/physique, grooming, posture, mindset, dating confidence, supplements (factual only),
mewing, fashion basics, outfit color theory, jewelry/accessories — and anything tied to
ascending their physical & social presence.

When recommending products, prefer India-available brands and quote prices in INR (₹):
Minimalist, The Derma Co, Plum, Foxtale, Dot & Key, Pilgrim, Mamaearth, Cetaphil India,
La Shield, Bombay Shaving Co, Beardo, WOW Skin Science, Bare Anatomy, Arata, The Man Company.

Voice rules:
- Direct, motivating, brutally honest but never cruel. Like an elite trainer.
- Concise: aim for 2-4 short paragraphs MAX (mobile-first).
- Use occasional sharp metaphors. Avoid corporate filler.
- Bullet points when listing steps or products.
- Never invent medical advice; for skin conditions / hair loss meds / hormone topics,
  recommend seeing a dermatologist or doctor explicitly.
- If the user goes off-topic, politely steer back to looksmaxxing.

When the user has a recent scan, reference their actual tier and scores naturally —
e.g., 'Given you're MTN with a 6.4 jaw...' — to make it personal.

Never reveal that you're Claude or any specific model. You are Mog."""


async def _load_recent_chat(user_id: str, limit: int = 12) -> List[dict]:
    cursor = (
        db["chat_messages"]
        .find({"user_id": user_id}, {"_id": 0})
        .sort("created_at", -1)
        .limit(limit)
    )
    docs = await cursor.to_list(length=limit)
    return list(reversed(docs))


async def _scan_context_for(user_id: str) -> str:
    """Latest scan as a compact context block for the coach."""
    doc = await scans_col.find_one(
        {"user_id": user_id},
        {"_id": 0, "image_b64": 0},
        sort=[("created_at", -1)],
    )
    if not doc:
        return "No scan yet."
    metrics = doc.get("metrics", [])
    metric_lines = ", ".join(
        f"{m.get('label', m.get('key', '?'))}: {m.get('score', 0):.1f}"
        for m in metrics[:11]
    )
    return (
        f"Latest scan — overall {doc.get('overall_score', 0):.1f}/10, "
        f"symmetry {doc.get('symmetry_score', 0):.1f}/10, "
        f"face shape {doc.get('face_shape')}, hairline {doc.get('hairline_type')}. "
        f"Metrics: {metric_lines}. "
        f"Verdict: {doc.get('summary', '')}"
    )


@api.get("/chat/history", response_model=List[ChatMessage])
async def chat_history(user: Annotated[dict, Depends(get_current_user)]):
    cursor = (
        db["chat_messages"]
        .find({"user_id": user["id"]}, {"_id": 0})
        .sort("created_at", 1)
        .limit(200)
    )
    docs = await cursor.to_list(length=200)
    return [
        ChatMessage(
            id=d["id"], role=d["role"], content=d["content"], created_at=d["created_at"]
        )
        for d in docs
    ]


@api.delete("/chat/history")
async def chat_clear(user: Annotated[dict, Depends(get_current_user)]):
    res = await db["chat_messages"].delete_many({"user_id": user["id"]})
    return {"deleted": res.deleted_count}


@api.post("/chat/message", response_model=ChatResponse)
async def chat_message(
    body: ChatMessageIn,
    user: Annotated[dict, Depends(get_current_user)],
):
    now = datetime.now(timezone.utc)
    user_doc = {
        "id": str(uuid.uuid4()),
        "user_id": user["id"],
        "role": "user",
        "content": body.message.strip(),
        "created_at": now,
    }
    await db["chat_messages"].insert_one(user_doc.copy())

    # Build context: most-recent history + scan summary
    recent = await _load_recent_chat(user["id"], limit=10)
    scan_ctx = await _scan_context_for(user["id"])

    session_id = f"coach-{user['id']}"
    system_with_ctx = COACH_SYSTEM_PROMPT + f"\n\n--- USER CONTEXT ---\n{scan_ctx}"

    chat = LlmChat(
        api_key=EMERGENT_LLM_KEY,
        session_id=session_id,
        system_message=system_with_ctx,
    ).with_model("anthropic", "claude-sonnet-4-6")

    # Replay recent history so the model sees context. We send the latest user msg
    # as the actual UserMessage; older history is folded into the system prompt as
    # plain text to keep the call cheap and stateless.
    history_blob = ""
    for m in recent[:-1]:  # exclude the just-inserted user msg
        role = "User" if m["role"] == "user" else "Mog"
        history_blob += f"\n{role}: {m['content']}"
    if history_blob:
        chat = LlmChat(
            api_key=EMERGENT_LLM_KEY,
            session_id=session_id,
            system_message=system_with_ctx
            + f"\n\n--- RECENT CONVERSATION ---{history_blob}",
        ).with_model("anthropic", "claude-sonnet-4-6")

    try:
        reply = await chat.send_message(UserMessage(text=body.message))
        reply_text = reply if isinstance(reply, str) else str(reply)
    except Exception as e:
        logger.exception("Coach reply failed")
        raise HTTPException(status_code=502, detail=f"Coach unavailable: {e}")

    assistant_doc = {
        "id": str(uuid.uuid4()),
        "user_id": user["id"],
        "role": "assistant",
        "content": reply_text.strip(),
        "created_at": datetime.now(timezone.utc),
    }
    await db["chat_messages"].insert_one(assistant_doc.copy())

    return ChatResponse(
        user_message=ChatMessage(**{k: v for k, v in user_doc.items() if k != "user_id"}),
        assistant_message=ChatMessage(**{k: v for k, v in assistant_doc.items() if k != "user_id"}),
    )



# ---------------------------------------------------------------------------
# Stripe Ascend subscription ($1/month — implemented as one-time test charge)
# ---------------------------------------------------------------------------
@api.post("/payments/create-checkout-session", response_model=CheckoutSessionResponse)
async def create_checkout(
    user: Annotated[dict, Depends(get_current_user)],
    request: Request,
):
    if user.get("is_premium"):
        raise HTTPException(status_code=400, detail="Already Ascended")
    origin = FRONTEND_BASE_URL or str(request.base_url).rstrip("/")
    try:
        req = CheckoutSessionRequest(
            amount=ASCEND_PRICE_USD,
            currency="usd",
            success_url=f"{origin}/payments/success?session_id={{CHECKOUT_SESSION_ID}}",
            cancel_url=f"{origin}/payments/cancel",
            metadata={
                "user_id": user["id"],
                "user_email": user["email"],
                "upgrade_type": "moglabs_ascend",
            },
        )
        session = await stripe_checkout.create_checkout_session(req)
    except Exception as e:
        logger.exception("Stripe checkout failed")
        raise HTTPException(status_code=502, detail=f"Stripe error: {e}")

    await payments_col.insert_one(
        {
            "session_id": session.session_id,
            "user_id": user["id"],
            "status": "pending",
            "amount_usd": ASCEND_PRICE_USD,
            "created_at": datetime.now(timezone.utc),
        }
    )
    return CheckoutSessionResponse(checkout_url=session.url, session_id=session.session_id)


@api.get("/payments/status/{session_id}")
async def payment_status(
    session_id: str,
    user: Annotated[dict, Depends(get_current_user)],
):
    try:
        status_res = await stripe_checkout.get_checkout_status(session_id)
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"Stripe error: {e}")
    paid = status_res.payment_status == "paid"
    if paid:
        await users_col.update_one(
            {"id": user["id"]},
            {"$set": {"is_premium": True, "premium_since": datetime.now(timezone.utc)}},
        )
        await payments_col.update_one(
            {"session_id": session_id},
            {"$set": {"status": "paid", "paid_at": datetime.now(timezone.utc)}},
        )
    return {"paid": paid, "payment_status": status_res.payment_status}


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------
@api.get("/")
async def root():
    return {"app": "Moglabs", "status": "ok"}


# Mount router
app.include_router(api)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
